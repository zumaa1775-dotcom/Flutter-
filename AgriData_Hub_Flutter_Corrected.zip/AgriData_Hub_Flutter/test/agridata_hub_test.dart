
import 'package:flutter_test/flutter_test.dart';
import 'package:agri_data_hub/main.dart';

void main() {
  test('phone validation matches the original requirement', () {
    expect(validPhone('0123456789'), isTrue);
    expect(validPhone('012345678'), isFalse);
    expect(validPhone('01234abc89'), isFalse);
  });

  test('planting dates require a four-digit year', () {
    expect(validPlantingDate('2026-10-06'), isTrue);
    expect(validPlantingDate('26-10-06'), isFalse);
  });
}
