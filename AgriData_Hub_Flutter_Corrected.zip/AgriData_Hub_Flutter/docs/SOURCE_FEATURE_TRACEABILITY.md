# Source Feature Traceability

Mapped from the supplied Flask project:

- `/api/register` -> `AppController.register`
- `/api/login` -> `AppController.login`
- `/api/forgot-password` + `/api/reset-password` -> reset methods
- `/api/me` -> `updateProfile`, `updateLanguage`
- `/api/settings` -> `updateSettings`
- `/api/crops` -> `CropsPage` + plant editor
- `/api/livestock` -> `LivestockPage` + livestock editor
- `/api/expenses` -> `ExpensesPage` + purchase editor
- `/api/income` -> `IncomePage` + sale editor
- `/api/notifications` -> notifications bottom sheet
- `/api/admin/users` + approval/rejection routes -> `AdminUsersPage` / `AdminDashboardPage`
- `/api/admin/stats` -> administrator dashboard counters
- `/api/dashboard` -> farmer dashboard counters
- `/api/reports` -> reports page
- `/api/market` -> private market catalogue
- `/api/sync` -> local synchronization queue and state

The old Flask source remains untouched under `legacy_reference/agridata hub/`.
