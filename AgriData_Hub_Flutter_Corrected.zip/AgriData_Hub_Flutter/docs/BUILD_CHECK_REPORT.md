# AgriData Hub Flutter — Build Check Report

## Checks completed in this environment

- `pubspec.yaml` parses successfully.
- `flutter_lints` is declared because `analysis_options.yaml` imports `package:flutter_lints/flutter.yaml`.
- Bootstrap and verification shell scripts pass `bash -n` syntax validation.
- Existing Dart source, assets, tests and legacy reference files were retained.
- The project still targets Web, Android and iOS from the same Flutter codebase.

## Checks that require a Flutter SDK

The execution environment used to prepare this ZIP does not contain the Flutter SDK, so the following could not be executed here:

- `flutter pub get`
- `flutter analyze`
- `flutter test`
- `flutter build web --release`
- `flutter build apk --release`
- `flutter build ios --release`

Use `tool/bootstrap_platforms.sh` (or the PowerShell equivalent) on a machine with Flutter installed. It generates the standard `android/`, `ios/` and `web/` platform scaffolding and resolves dependencies. Then run `tool/verify_and_build.sh`.

## Why Android/iOS folders are not hard-coded into this archive

Flutter's native platform folders are generated from the installed Flutter SDK and should match the local Android Gradle/Xcode toolchain. Generating them with an unavailable SDK would risk shipping stale or incompatible native project files. The supplied bootstrap script creates them with the user's installed Flutter version.
