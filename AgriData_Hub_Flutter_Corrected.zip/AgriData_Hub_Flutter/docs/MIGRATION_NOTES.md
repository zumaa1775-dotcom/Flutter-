# Migration Notes

Source: supplied `agridata hub(1).zip`.

## Flask -> Flutter

The Flask server, Jinja template and JavaScript fetch layer were replaced by a Flutter/Dart application. The original project remains under `legacy_reference/agridata hub/`.

## Preserved functionality

- Two roles only: Administrator and Farmer.
- Farmer registration and administrator approval/rejection.
- Login, offline login and password reset.
- Crops, livestock, purchases, sales, reports and private market catalogue.
- Notifications, user profile, settings and help/about.
- Offline/local-first record keeping and synchronization screen.
- Existing database records copied into `assets/seed_data.json`.

## Intentional infrastructure difference

The original project relied on Flask sessions and a shared server-side SQLite database for multi-device access. Flutter alone cannot act as the shared server/database for multiple devices. This migration therefore uses local persistence so Android, iOS and web all run from one application codebase. A future cloud adapter can be added to `DataRepository` without changing the UI.
