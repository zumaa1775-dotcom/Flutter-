from flask import Flask, render_template, request, jsonify, session
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
import sqlite3, os, secrets, smtplib, re
from email.message import EmailMessage
from datetime import datetime, timedelta

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "agridata.db")
app = Flask(__name__)
app.secret_key = os.environ.get("AGRIDATA_SECRET_KEY", "change-this-secret-in-production")


def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def now():
    return datetime.now().isoformat(timespec="seconds")


def valid_phone(phone):
    return bool(re.fullmatch(r"\d{10}", phone or ""))


def valid_planting_date(value):
    if not value:
        return True
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
        return False
    try:
        datetime.strptime(value, "%Y-%m-%d")
        return True
    except ValueError:
        return False


def init_db():
    conn = db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT UNIQUE,
        email TEXT UNIQUE,
        password_hash TEXT NOT NULL,
        language TEXT NOT NULL DEFAULT 'English',
        role TEXT NOT NULL DEFAULT 'user',
        status TEXT NOT NULL DEFAULT 'pending',
        created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS user_settings (
        user_id INTEGER PRIMARY KEY,
        theme TEXT NOT NULL DEFAULT 'light',
        accent TEXT NOT NULL DEFAULT '#6b3f17',
        notifications INTEGER NOT NULL DEFAULT 1,
        compact_mode INTEGER NOT NULL DEFAULT 0,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS password_resets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        code TEXT NOT NULL,
        expires_at TEXT NOT NULL,
        used INTEGER NOT NULL DEFAULT 0,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS crops (
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, name TEXT NOT NULL,
        planting_date TEXT, area REAL DEFAULT 0, icon TEXT DEFAULT '🌱', created_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS livestock (
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, animal_type TEXT NOT NULL,
        quantity INTEGER NOT NULL DEFAULT 1, record_type TEXT NOT NULL DEFAULT 'Added', record_date TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS expenses (
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, description TEXT NOT NULL,
        category TEXT NOT NULL, amount REAL NOT NULL, expense_date TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS income (
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, item TEXT NOT NULL,
        quantity TEXT, amount REAL NOT NULL, sale_date TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS market_catalogue (
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, product TEXT NOT NULL,
        category TEXT NOT NULL DEFAULT 'Crop', unit TEXT NOT NULL DEFAULT 'kg', price REAL NOT NULL,
        notes TEXT DEFAULT '', created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, kind TEXT NOT NULL,
        title TEXT NOT NULL, message TEXT NOT NULL, is_read INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS admin_profiles (
        user_id INTEGER PRIMARY KEY,
        department TEXT DEFAULT 'System Administration',
        last_login TEXT,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS audit_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER, action TEXT NOT NULL, details TEXT, created_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL
    );
    CREATE TABLE IF NOT EXISTS sync_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, synced_at TEXT NOT NULL,
        status TEXT NOT NULL, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    """)
    # Safe migration for databases from the original version.
    cols = {r[1] for r in conn.execute("PRAGMA table_info(users)").fetchall()}
    if "email" not in cols:
        conn.execute("ALTER TABLE users ADD COLUMN email TEXT")
    role_migrated = "role" not in cols
    status_migrated = "status" not in cols
    if role_migrated:
        conn.execute("ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'user'")
    if status_migrated:
        conn.execute("ALTER TABLE users ADD COLUMN status TEXT NOT NULL DEFAULT 'approved'")
    # Create a first administrator for a fresh/demo installation. Change the password after first login.
    admin = conn.execute("SELECT id FROM users WHERE role='admin' LIMIT 1").fetchone()
    if not admin:
        conn.execute("INSERT INTO users(name,phone,email,password_hash,language,role,status,created_at) VALUES(?,?,?,?,?,?,?,?)",
                     ('System Administrator', None, 'admin@agridata.local', generate_password_hash('Admin@12345'), 'English', 'admin', 'approved', now()))
        aid=conn.execute("SELECT last_insert_rowid()").fetchone()[0]
        conn.execute("INSERT OR IGNORE INTO user_settings(user_id) VALUES(?)", (aid,))
        conn.execute("INSERT OR IGNORE INTO admin_profiles(user_id) VALUES(?)", (aid,))
    # This build has only two roles: admin and farmer (stored as role='user').
    # Convert legacy extension-officer accounts to approved farmers so old databases remain usable.
    conn.execute("UPDATE users SET role='user', status='approved' WHERE role='extension_officer'")
    # Legacy extension-only records are intentionally removed because the role no longer exists.
    conn.execute("DROP TABLE IF EXISTS recommendations")
    conn.execute("DROP TABLE IF EXISTS extension_officer_profiles")
    for r in conn.execute("SELECT id FROM users WHERE role='admin'").fetchall():
        conn.execute("INSERT OR IGNORE INTO admin_profiles(user_id) VALUES(?)", (r['id'],))
    conn.execute("DELETE FROM users WHERE role NOT IN ('admin','user')")
    conn.commit()
    conn.close()


def ensure_user_settings(uid):
    conn = db()
    conn.execute("INSERT OR IGNORE INTO user_settings(user_id) VALUES(?)", (uid,))
    conn.commit(); conn.close()


def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            return jsonify({"error": "Authentication required"}), 401
        return fn(*args, **kwargs)
    return wrapper


def uid(): return session["user_id"]


def notify(uid_value, kind, title, message):
    conn = db()
    conn.execute("INSERT INTO notifications(user_id,kind,title,message,created_at) VALUES(?,?,?,?,?)",
                 (uid_value, kind, title, message, now()))
    conn.commit(); conn.close()


def send_reset_email(email, code):
    host = os.environ.get("AGRIDATA_SMTP_HOST")
    port = int(os.environ.get("AGRIDATA_SMTP_PORT", "587"))
    username = os.environ.get("AGRIDATA_SMTP_USER")
    password = os.environ.get("AGRIDATA_SMTP_PASSWORD")
    sender = os.environ.get("AGRIDATA_SMTP_FROM", username or "no-reply@agridata.local")
    if not (host and username and password):
        return False
    msg = EmailMessage()
    msg["Subject"] = "AgriData Hub password reset code"
    msg["From"] = sender; msg["To"] = email
    msg.set_content(f"Your AgriData Hub password reset code is {code}. It expires in 15 minutes.")
    with smtplib.SMTP(host, port, timeout=15) as smtp:
        smtp.starttls(); smtp.login(username, password); smtp.send_message(msg)
    return True


@app.route("/")
def index(): return render_template("index.html")

@app.route("/sw.js")
def service_worker(): return app.send_static_file("sw.js")

@app.post("/api/register")
def register():
    d=request.get_json() or {}; name=d.get("name","").strip(); phone=d.get("phone","").strip() or None
    email=d.get("email","").strip().lower() or None; password=d.get("password",""); language=d.get("language","English")
    if phone and not valid_phone(phone):
        return jsonify({"error":"Phone number must contain exactly 10 digits."}),400
    if not name or not (phone or email) or len(password)<6:
        return jsonify({"error":"Name, email or phone, and a password of at least 6 characters are required."}),400
    conn=db()
    try:
        cur=conn.execute("INSERT INTO users(name,phone,email,password_hash,language,role,status,created_at) VALUES(?,?,?,?,?,?,?,?)",
            (name,phone,email,generate_password_hash(password),language,'user','pending',now()))
        uid_new=cur.lastrowid; conn.execute("INSERT INTO user_settings(user_id) VALUES(?)",(uid_new,)); conn.commit()
        # Notify all administrators that a new farmer is waiting for approval.
        admins=conn.execute("SELECT id FROM users WHERE role='admin'").fetchall()
        for a in admins:
            conn.execute("INSERT INTO notifications(user_id,kind,title,message,created_at) VALUES(?,?,?,?,?)",
                         (a['id'],'approval','New registration request',f'{name} has requested access to AgriData Hub.',now()))
        conn.commit()
        return jsonify({"ok":True,"pending":True,"message":"Registration submitted. An administrator must approve your account before you can log in."})
    except sqlite3.IntegrityError:
        return jsonify({"error":"That email or phone number is already registered."}),409
    finally: conn.close()

@app.post("/api/login")
def login():
    d=request.get_json() or {}; identifier=d.get("identifier","").strip().lower(); password=d.get("password",""); requested_role=d.get("role","auto")
    conn=db(); row=conn.execute("SELECT * FROM users WHERE lower(phone)=? OR lower(email)=?",(identifier,identifier)).fetchone()
    if not row or not check_password_hash(row["password_hash"],password):
        conn.close(); return jsonify({"error":"Invalid email/phone or password."}),401
    if requested_role not in ('auto','user','admin'):
        conn.close(); return jsonify({"error":"Invalid login role. Choose Administrator or Farmer."}),400
    if requested_role != 'auto' and row['role'] != requested_role:
        conn.close(); return jsonify({"error":f"This account is registered as {row['role'].replace('_',' ').title()}, not {requested_role.replace('_',' ').title()}."}),403
    if row['status'] != 'approved':
        if row['status'] == 'rejected': conn.close(); return jsonify({"error":"Your registration request was rejected. Please contact the administrator."}),403
        conn.close(); return jsonify({"error":"Your registration is waiting for administrator approval."}),403
    session["user_id"]=row["id"]; ensure_user_settings(row["id"])
    if row['role']=='admin': conn.execute("INSERT OR IGNORE INTO admin_profiles(user_id) VALUES(?)", (row['id'],)); conn.execute("UPDATE admin_profiles SET last_login=? WHERE user_id=?", (now(),row['id']))
    conn.execute("INSERT INTO audit_log(user_id,action,details,created_at) VALUES(?,?,?,?)", (row['id'],'login',f'Role: {row["role"]}',now())); conn.commit(); conn.close()
    return jsonify({"ok":True,"user":{"name":row["name"],"phone":row["phone"],"email":row["email"],"language":row["language"],"role":row['role'],"status":row['status']}})

@app.post("/api/logout")
def logout(): session.clear(); return jsonify({"ok":True})

@app.get("/api/me")
@login_required
def me():
    conn=db(); row=conn.execute("SELECT id,name,phone,email,language,role,status FROM users WHERE id=?",(uid(),)).fetchone(); conn.close(); return jsonify(dict(row))

@app.put("/api/me")
@login_required
def update_me():
    d=request.get_json() or {}; name=d.get("name","").strip(); phone=d.get("phone","").strip() or None; email=d.get("email","").strip().lower() or None; language=d.get("language","English")
    if phone and not valid_phone(phone): return jsonify({"error":"Phone number must contain exactly 10 digits."}),400
    if not name or not (phone or email): return jsonify({"error":"Name and at least one contact method are required."}),400
    conn=db()
    try:
        conn.execute("UPDATE users SET name=?,phone=?,email=?,language=? WHERE id=?",(name,phone,email,language,uid())); conn.commit()
        return jsonify({"ok":True})
    except sqlite3.IntegrityError: return jsonify({"error":"That email or phone is already in use."}),409
    finally: conn.close()

@app.post("/api/forgot-password")
def forgot_password():
    identifier=(request.get_json() or {}).get("identifier","").strip().lower()
    if not identifier: return jsonify({"error":"Enter your email address or phone number."}),400
    conn=db(); row=conn.execute("SELECT id,email,phone FROM users WHERE lower(email)=? OR lower(phone)=?",(identifier,identifier)).fetchone()
    if not row:
        conn.close(); return jsonify({"ok":True,"message":"If an account matches, a reset code has been prepared."})
    code=f"{secrets.randbelow(1000000):06d}"; expires=(datetime.now()+timedelta(minutes=15)).isoformat(timespec="seconds")
    conn.execute("UPDATE password_resets SET used=1 WHERE user_id=? AND used=0",(row["id"],)); conn.execute("INSERT INTO password_resets(user_id,code,expires_at) VALUES(?,?,?)",(row["id"],code,expires)); conn.commit(); conn.close()
    delivered=False
    if row["email"]:
        try: delivered=send_reset_email(row["email"],code)
        except Exception: delivered=False
    # Demo fallback makes the feature usable without an SMS/SMTP provider.
    return jsonify({"ok":True,"delivered":delivered,"demo_code":None if delivered else code,"message":"A reset code was sent." if delivered else "SMTP/SMS is not configured, so this development build shows the reset code on screen."})

@app.post("/api/reset-password")
def reset_password():
    d=request.get_json() or {}; identifier=d.get("identifier","").strip().lower(); code=d.get("code","").strip(); password=d.get("password","")
    if len(password)<6: return jsonify({"error":"New password must be at least 6 characters."}),400
    conn=db(); user=conn.execute("SELECT id FROM users WHERE lower(email)=? OR lower(phone)=?",(identifier,identifier)).fetchone()
    if not user: conn.close(); return jsonify({"error":"Account not found."}),404
    reset=conn.execute("SELECT id FROM password_resets WHERE user_id=? AND code=? AND used=0 AND expires_at>=? ORDER BY id DESC LIMIT 1",(user["id"],code,now())).fetchone()
    if not reset: conn.close(); return jsonify({"error":"Invalid or expired reset code."}),400
    conn.execute("UPDATE users SET password_hash=? WHERE id=?",(generate_password_hash(password),user["id"])); conn.execute("UPDATE password_resets SET used=1 WHERE id=?",(reset["id"],)); conn.commit(); conn.close()
    return jsonify({"ok":True,"message":"Password changed successfully."})

@app.get("/api/settings")
@login_required
def get_settings():
    ensure_user_settings(uid()); conn=db(); row=conn.execute("SELECT * FROM user_settings WHERE user_id=?",(uid(),)).fetchone(); conn.close(); return jsonify(dict(row))

@app.put("/api/settings")
@login_required
def put_settings():
    d=request.get_json() or {}; theme=d.get("theme","light"); accent=d.get("accent","#6b3f17"); notifications=1 if d.get("notifications",True) else 0; compact=1 if d.get("compact_mode",False) else 0
    if theme not in ("light","dark"): theme="light"
    ensure_user_settings(uid()); conn=db(); conn.execute("UPDATE user_settings SET theme=?,accent=?,notifications=?,compact_mode=? WHERE user_id=?",(theme,accent,notifications,compact,uid())); conn.commit(); conn.close(); return jsonify({"ok":True})


def current_user():
    conn=db(); row=conn.execute("SELECT * FROM users WHERE id=?",(uid(),)).fetchone(); conn.close(); return row

def role_required(*roles):
    def deco(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            if "user_id" not in session: return jsonify({"error":"Authentication required"}),401
            row=current_user()
            if not row or row['role'] not in roles: return jsonify({"error":"You do not have permission for this area."}),403
            return fn(*args, **kwargs)
        return wrapper
    return deco

def crud_list(table, order="id DESC"):
    conn=db(); rows=conn.execute(f"SELECT * FROM {table} WHERE user_id=? ORDER BY {order}",(uid(),)).fetchall(); conn.close(); return [dict(r) for r in rows]

@app.get("/api/crops")
@login_required
def crops(): return jsonify(crud_list("crops"))
@app.post("/api/crops")
@login_required
def add_crop():
    d=request.get_json() or {}
    planting_date=d.get("planting_date") or None
    if not d.get("name"): return jsonify({"error":"Plant name is required."}),400
    if not valid_planting_date(planting_date): return jsonify({"error":"Planting date must use a four-digit year in YYYY-MM-DD format."}),400
    conn=db(); cur=conn.execute("INSERT INTO crops(user_id,name,planting_date,area,icon,created_at) VALUES(?,?,?,?,?,?)",(uid(),d["name"],planting_date,float(d.get("area") or 0),d.get("icon","🌱"),now())); conn.commit(); row=conn.execute("SELECT * FROM crops WHERE id=?",(cur.lastrowid,)).fetchone(); conn.close(); return jsonify(dict(row)),201
@app.put("/api/crops/<int:item_id>")
@login_required
def edit_crop(item_id):
    d=request.get_json() or {}; planting_date=d.get("planting_date") or None
    if not d.get("name"): return jsonify({"error":"Plant name is required."}),400
    if not valid_planting_date(planting_date): return jsonify({"error":"Planting date must use a four-digit year in YYYY-MM-DD format."}),400
    conn=db(); cur=conn.execute("UPDATE crops SET name=?,planting_date=?,area=?,icon=? WHERE id=? AND user_id=?",(d.get("name"),planting_date,float(d.get("area") or 0),d.get("icon","🌱"),item_id,uid())); conn.commit(); conn.close(); return jsonify({"ok":cur.rowcount>0})
@app.delete("/api/crops/<int:item_id>")
@login_required
def delete_crop(item_id):
    conn=db(); cur=conn.execute("DELETE FROM crops WHERE id=? AND user_id=?",(item_id,uid())); conn.commit(); conn.close(); return jsonify({"ok":cur.rowcount>0})

@app.get("/api/livestock")
@login_required
def livestock(): return jsonify(crud_list("livestock","id DESC"))
@app.post("/api/livestock")
@login_required
def add_livestock():
    d=request.get_json() or {}; animal=d.get("animal_type","Cattle"); qty=int(d.get("quantity") or 1); record=d.get("record_type","Added"); date=d.get("record_date") or datetime.now().strftime("%Y-%m-%d")
    conn=db(); cur=conn.execute("INSERT INTO livestock(user_id,animal_type,quantity,record_type,record_date) VALUES(?,?,?,?,?)",(uid(),animal,qty,record,date)); conn.commit(); row=conn.execute("SELECT * FROM livestock WHERE id=?",(cur.lastrowid,)).fetchone(); conn.close()
    notify(uid(),"livestock","Livestock updated",f"{qty} {animal} recorded as {record}."); return jsonify(dict(row)),201
@app.delete("/api/livestock/<int:item_id>")
@login_required
def delete_livestock(item_id):
    conn=db(); cur=conn.execute("DELETE FROM livestock WHERE id=? AND user_id=?",(item_id,uid())); conn.commit(); conn.close(); return jsonify({"ok":cur.rowcount>0})

@app.get("/api/expenses")
@login_required
def expenses(): return jsonify(crud_list("expenses","expense_date DESC,id DESC"))
@app.post("/api/expenses")
@login_required
def add_expense():
    d=request.get_json() or {}; amount=float(d.get("amount") or 0); conn=db(); cur=conn.execute("INSERT INTO expenses(user_id,description,category,amount,expense_date) VALUES(?,?,?,?,?)",(uid(),d.get("description"),d.get("category","Other"),amount,d.get("expense_date") or datetime.now().strftime("%Y-%m-%d"))); conn.commit(); row=conn.execute("SELECT * FROM expenses WHERE id=?",(cur.lastrowid,)).fetchone(); conn.close(); notify(uid(),"purchase","Purchase recorded",f"{d.get('description','Farm purchase')} — R {amount:,.2f}."); return jsonify(dict(row)),201
@app.delete("/api/expenses/<int:item_id>")
@login_required
def delete_expense(item_id):
    conn=db(); cur=conn.execute("DELETE FROM expenses WHERE id=? AND user_id=?",(item_id,uid())); conn.commit(); conn.close(); return jsonify({"ok":cur.rowcount>0})

@app.get("/api/income")
@login_required
def income(): return jsonify(crud_list("income","sale_date DESC,id DESC"))
@app.post("/api/income")
@login_required
def add_income():
    d=request.get_json() or {}; amount=float(d.get("amount") or 0); conn=db(); cur=conn.execute("INSERT INTO income(user_id,item,quantity,amount,sale_date) VALUES(?,?,?,?,?)",(uid(),d.get("item"),d.get("quantity",""),amount,d.get("sale_date") or datetime.now().strftime("%Y-%m-%d"))); conn.commit(); row=conn.execute("SELECT * FROM income WHERE id=?",(cur.lastrowid,)).fetchone(); conn.close(); notify(uid(),"sale","Sale recorded",f"{d.get('item','Farm product')} — R {amount:,.2f}."); return jsonify(dict(row)),201
@app.delete("/api/income/<int:item_id>")
@login_required
def delete_income(item_id):
    conn=db(); cur=conn.execute("DELETE FROM income WHERE id=? AND user_id=?",(item_id,uid())); conn.commit(); conn.close(); return jsonify({"ok":cur.rowcount>0})

@app.get("/api/notifications")
@login_required
def notifications():
    conn=db(); rows=conn.execute("SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 50",(uid(),)).fetchall(); unread=conn.execute("SELECT COUNT(*) c FROM notifications WHERE user_id=? AND is_read=0",(uid(),)).fetchone()["c"]; conn.close(); return jsonify({"items":[dict(x) for x in rows],"unread":unread})
@app.post("/api/notifications/read")
@login_required
def notifications_read():
    conn=db(); conn.execute("UPDATE notifications SET is_read=1 WHERE user_id=?",(uid(),)); conn.commit(); conn.close(); return jsonify({"ok":True})

@app.get("/api/admin/users")
@role_required('admin')
def admin_users():
    conn=db(); rows=conn.execute("SELECT id,name,phone,email,role,status,created_at FROM users WHERE role IN ('admin','user') ORDER BY CASE status WHEN 'pending' THEN 0 ELSE 1 END, created_at DESC").fetchall(); conn.close(); return jsonify([dict(r) for r in rows])

@app.post("/api/admin/users/<int:user_id>/approve")
@role_required('admin')
def approve_user(user_id):
    conn=db(); row=conn.execute("SELECT * FROM users WHERE id=? AND role='user'",(user_id,)).fetchone()
    if not row: conn.close(); return jsonify({"error":"Farmer not found."}),404
    conn.execute("UPDATE users SET status='approved' WHERE id=?",(user_id,)); conn.execute("INSERT INTO notifications(user_id,kind,title,message,created_at) VALUES(?,?,?,?,?)",(user_id,'approval','Account approved','Your AgriData Hub farmer account has been approved. You can now log in.',now())); conn.commit(); conn.close(); return jsonify({"ok":True})

@app.post("/api/admin/users/<int:user_id>/reject")
@role_required('admin')
def reject_user(user_id):
    conn=db(); row=conn.execute("SELECT * FROM users WHERE id=? AND role='user'",(user_id,)).fetchone()
    if not row: conn.close(); return jsonify({"error":"Farmer not found."}),404
    conn.execute("UPDATE users SET status='rejected' WHERE id=?",(user_id,)); conn.execute("INSERT INTO notifications(user_id,kind,title,message,created_at) VALUES(?,?,?,?,?)",(user_id,'approval','Registration request update','Your AgriData Hub registration request was rejected. Please contact the administrator.',now())); conn.commit(); conn.close(); return jsonify({"ok":True})

@app.get("/api/admin/stats")
@role_required('admin')
def admin_stats():
    conn=db(); stats={
      'farmers':conn.execute("SELECT COUNT(*) c FROM users WHERE role='user'").fetchone()['c'],
      'pending':conn.execute("SELECT COUNT(*) c FROM users WHERE role='user' AND status='pending'").fetchone()['c'],
      'approved':conn.execute("SELECT COUNT(*) c FROM users WHERE role='user' AND status='approved'").fetchone()['c'],
      'rejected':conn.execute("SELECT COUNT(*) c FROM users WHERE role='user' AND status='rejected'").fetchone()['c'],
      'admins':conn.execute("SELECT COUNT(*) c FROM users WHERE role='admin'").fetchone()['c'],
      'new_today':conn.execute("SELECT COUNT(*) c FROM users WHERE role='user' AND date(created_at)=date('now','localtime')").fetchone()['c']}; conn.close(); return jsonify(stats)

@app.get("/api/dashboard")
@login_required
def dashboard():
    conn=db(); me=conn.execute("SELECT role,status FROM users WHERE id=?",(uid(),)).fetchone(); crops_n=conn.execute("SELECT COUNT(*) c FROM crops WHERE user_id=?",(uid(),)).fetchone()["c"]; livestock_n=conn.execute("SELECT COALESCE(SUM(quantity),0) c FROM livestock WHERE user_id=?",(uid(),)).fetchone()["c"]; income_n=conn.execute("SELECT COALESCE(SUM(amount),0) n FROM income WHERE user_id=?",(uid(),)).fetchone()["n"]; expenses_n=conn.execute("SELECT COALESCE(SUM(amount),0) n FROM expenses WHERE user_id=?",(uid(),)).fetchone()["n"]; last=conn.execute("SELECT synced_at,status FROM sync_log WHERE user_id=? ORDER BY id DESC LIMIT 1",(uid(),)).fetchone(); conn.close(); return jsonify({"crops":crops_n,"livestock":livestock_n,"income":income_n,"expenses":expenses_n,"profit":income_n-expenses_n,"last_sync":dict(last) if last else None,"role":me['role'],"status":me['status']})

@app.get("/api/reports")
@login_required
def reports():
    conn=db(); by_crop=conn.execute("SELECT name,area,planting_date FROM crops WHERE user_id=? ORDER BY name",(uid(),)).fetchall(); by_animal=conn.execute("SELECT animal_type,SUM(quantity) quantity FROM livestock WHERE user_id=? GROUP BY animal_type",(uid(),)).fetchall(); conn.close(); return jsonify({"crops":[dict(x) for x in by_crop],"livestock":[dict(x) for x in by_animal]})

@app.get("/api/market")
@login_required
def market():
    conn=db(); rows=conn.execute("SELECT * FROM market_catalogue WHERE user_id=? ORDER BY product COLLATE NOCASE",(uid(),)).fetchall(); conn.close()
    return jsonify({"updated":datetime.now().strftime("%Y-%m-%d %H:%M"),"catalogue":[dict(x) for x in rows]})

@app.post("/api/market")
@login_required
def add_market_item():
    d=request.get_json() or {}; product=d.get('product','').strip(); category=d.get('category','Crop').strip(); unit=d.get('unit','kg').strip(); notes=d.get('notes','').strip()
    try: price=float(d.get('price'))
    except (TypeError,ValueError): return jsonify({"error":"Enter a valid price."}),400
    if not product or not unit: return jsonify({"error":"Product and unit are required."}),400
    if price < 0: return jsonify({"error":"Price cannot be negative."}),400
    t=now(); conn=db(); cur=conn.execute("INSERT INTO market_catalogue(user_id,product,category,unit,price,notes,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)",(uid(),product,category,unit,price,notes,t,t)); conn.commit(); row=conn.execute("SELECT * FROM market_catalogue WHERE id=?",(cur.lastrowid,)).fetchone(); conn.close(); return jsonify(dict(row)),201

@app.put("/api/market/<int:item_id>")
@login_required
def edit_market_item(item_id):
    d=request.get_json() or {}; product=d.get('product','').strip(); category=d.get('category','Crop').strip(); unit=d.get('unit','kg').strip(); notes=d.get('notes','').strip()
    try: price=float(d.get('price'))
    except (TypeError,ValueError): return jsonify({"error":"Enter a valid price."}),400
    if not product or not unit: return jsonify({"error":"Product and unit are required."}),400
    if price < 0: return jsonify({"error":"Price cannot be negative."}),400
    conn=db(); cur=conn.execute("UPDATE market_catalogue SET product=?,category=?,unit=?,price=?,notes=?,updated_at=? WHERE id=? AND user_id=?",(product,category,unit,price,notes,now(),item_id,uid())); conn.commit(); conn.close(); return jsonify({"ok":cur.rowcount>0})

@app.delete("/api/market/<int:item_id>")
@login_required
def delete_market_item(item_id):
    conn=db(); cur=conn.execute("DELETE FROM market_catalogue WHERE id=? AND user_id=?",(item_id,uid())); conn.commit(); conn.close(); return jsonify({"ok":cur.rowcount>0})

@app.post("/api/sync")
@login_required
def sync():
    d=request.get_json() or {}; records=d.get("records") or []
    me=current_user()
    if me['role']!='user' and records:
        return jsonify({"error":"Only farmer records can be synchronized from Offline Mode."}),403
    synced=0; failed=[]; conn=db()
    try:
        for rec in records:
            try:
                entity=rec.get('entity'); action=rec.get('action'); item_id=rec.get('localId'); payload=rec.get('data') or {}
                if entity=='crops':
                    if action=='create':
                        if not payload.get('name'): raise ValueError('Plant name is required.')
                        if not valid_planting_date(payload.get('planting_date')): raise ValueError('Planting date must use YYYY-MM-DD.')
                        cur=conn.execute("INSERT INTO crops(user_id,name,planting_date,area,icon,created_at) VALUES(?,?,?,?,?,?)",(uid(),payload.get('name'),payload.get('planting_date') or None,float(payload.get('area') or 0),payload.get('icon') or '🌱',now()))
                    elif action=='update':
                        if not str(item_id).isdigit(): raise ValueError('Cannot update an unsynchronized plant.')
                        conn.execute("UPDATE crops SET name=?,planting_date=?,area=?,icon=? WHERE id=? AND user_id=?",(payload.get('name'),payload.get('planting_date') or None,float(payload.get('area') or 0),payload.get('icon') or '🌱',int(item_id),uid()))
                    elif action=='delete' and str(item_id).isdigit(): conn.execute("DELETE FROM crops WHERE id=? AND user_id=?",(int(item_id),uid()))
                    else: raise ValueError('Invalid crop synchronization record.')
                elif entity=='livestock':
                    if action=='create':
                        cur=conn.execute("INSERT INTO livestock(user_id,animal_type,quantity,record_type,record_date) VALUES(?,?,?,?,?)",(uid(),payload.get('animal_type','Cattle'),int(payload.get('quantity') or 1),payload.get('record_type','Added'),payload.get('record_date') or datetime.now().strftime('%Y-%m-%d')))
                    elif action=='delete' and str(item_id).isdigit(): conn.execute("DELETE FROM livestock WHERE id=? AND user_id=?",(int(item_id),uid()))
                    else: raise ValueError('Invalid livestock synchronization record.')
                else: raise ValueError('Unsupported offline record type.')
                synced+=1
            except Exception as ex:
                failed.append({"record":rec,"error":str(ex)})
        t=now(); conn.execute("INSERT INTO sync_log(user_id,synced_at,status) VALUES(?,?,?)",(uid(),t,"Success" if not failed else "Partial")); conn.commit()
        return jsonify({"ok":not failed,"synced":synced,"failed":failed,"synced_at":t})
    finally: conn.close()

if __name__=="__main__":
    init_db(); app.run(debug=os.environ.get("AGRIDATA_DEBUG","false").lower()=="true",host=os.environ.get("AGRIDATA_HOST","0.0.0.0"),port=int(os.environ.get("AGRIDATA_PORT","5000")))
