# AgriData Hub — Updated Role-Based Edition

AgriData Hub is a Flask + SQLite progressive web application for farmers and administrators.

## Roles

The application now has **only two roles**:

- **Administrator** — manages farmer registrations, approvals/rejections, user accounts and system administration.
- **Farmer** — manages plants, livestock, purchases, sales, reports and a personal market-price catalogue.

The Extension Officer role and its user interface/workflows have been removed.

## Updated features

- Login as **Administrator** or **Farmer** only.
- Phone numbers accept **exactly 10 digits** and no other characters.
- The same 10-digit validation is enforced by the server for registration and profile updates.
- **Offline Login** now requires the user's saved account credentials. It no longer opens the farmer dashboard without authentication.
- Offline access is available on a device only after that account has successfully logged in online at least once on that device.
- Planting dates use `YYYY-MM-DD` and the server requires a four-digit year.
- Farmer dashboard no longer contains Recommendations.
- Extension Officer accounts, dashboards, recommendations and management screens have been removed.
- Administrator dashboard is focused on administrative duties: farmer registration status, approvals, account status and administrator count. Farm sales, purchases, crops and livestock are not shown there.
- Market Prices is now a **farmer-owned Price Catalogue** where a farmer can add, edit and delete products and set their own price, unit, category and optional notes.

## Run in VS Code

1. Open this project folder in VS Code.
2. Create/activate a Python virtual environment.
3. Install dependencies:

```bash
pip install -r requirements.txt
```

4. Start the server:

```bash
python app.py
```

5. Open:

`http://127.0.0.1:5000`

### Access from a phone on the same Wi-Fi

Run the server on the PC with host `0.0.0.0` (the project already does). Find the PC's local IP, for example `192.168.1.20`, then open:

`http://192.168.1.20:5000`

on the phone while both devices are on the same network.

## Demo administrator

- Email: `admin@agridata.local`
- Password: `Admin@12345`

Change the password before production use.

## Farmer registration workflow

1. A farmer registers with email or a 10-digit phone number (at least one contact method is required).
2. The account is saved as **Pending**.
3. The administrator approves or rejects the request.
4. Only approved farmers can log in.

## Market Price Catalogue

Each farmer has a private catalogue. A catalogue entry contains:

- Product name
- Category: Crop, Livestock or Other
- Unit: kg, ton, bag, crate, head, dozen or each
- Farmer's price in Rand
- Optional notes such as grade, quality or size

Prices can be edited or removed at any time.

## Offline login

The first successful online login on a device creates a local credential verifier. Selecting **Login Offline** then requires the same email/phone and password before the offline farmer dashboard opens. The password itself is not stored by the application.

## Production note

SQLite is suitable for development and small single-server deployments. For larger deployments, use PostgreSQL/MySQL, HTTPS and a strong `AGRIDATA_SECRET_KEY`.
