$ErrorActionPreference = 'Stop'

# Generate the native Flutter shells while keeping the existing Dart/Web source intact.
flutter create . --platforms=android,ios,web --project-name=agri_data_hub
flutter pub get

Write-Host "Platform scaffolding created successfully."
Write-Host "Next steps:"
Write-Host "  flutter analyze"
Write-Host "  flutter test"
Write-Host "  flutter build web --release"
Write-Host "  flutter build apk --release       # Android"
Write-Host "  flutter build ios --release       # macOS + Xcode required"
