#!/usr/bin/env bash
set -euo pipefail

# Generate the native Flutter shells while keeping the existing Dart/Web source intact.
flutter create . --platforms=android,ios,web --project-name=agri_data_hub
flutter pub get

echo "Platform scaffolding created successfully."
echo "Next steps:"
echo "  flutter analyze"
echo "  flutter test"
echo "  flutter build web --release"
echo "  flutter build apk --release       # Android"
echo "  flutter build ios --release       # macOS + Xcode required"
