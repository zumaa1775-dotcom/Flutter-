$ErrorActionPreference = 'Stop'

flutter pub get
flutter analyze
flutter test
flutter build web --release

Write-Host "Web verification/build completed."
Write-Host "For Android run: flutter build apk --release"
Write-Host "For iOS run on macOS with Xcode: flutter build ios --release"
