#!/usr/bin/env bash
set -euo pipefail

flutter pub get
flutter analyze
flutter test
flutter build web --release

echo "Web verification/build completed."
echo "For Android run: flutter build apk --release"
echo "For iOS run on macOS with Xcode: flutter build ios --release"
