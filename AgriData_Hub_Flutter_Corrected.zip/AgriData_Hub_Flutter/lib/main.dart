
import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hashlib/hashlib.dart';
import 'package:shared_preferences/shared_preferences.dart';

const brown = Color(0xFF6B3F17);
const green = Color(0xFF2E7D32);
const red = Color(0xFFC62828);

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = LocalStore();
  await store.init();
  final controller = AppController(store);
  await controller.restoreSession();
  runApp(AgriDataHubApp(controller: controller));
}

class LocalStore {
  static const _key = 'agridata_flutter_store_v2';
  final SharedPreferencesAsync _prefs = SharedPreferencesAsync();
  Map<String, dynamic> _data = {};

  Future<void> init() async {
    final raw = await _prefs.getString(_key);
    if (raw == null || raw.isEmpty) {
      final seed = await rootBundle.loadString('assets/seed_data.json');
      _data = Map<String, dynamic>.from(jsonDecode(seed));
      _normalizeSeed();
      await _save();
    } else {
      _data = Map<String, dynamic>.from(jsonDecode(raw));
      _normalizeSeed();
    }
  }

  void _normalizeSeed() {
    const tables = [
      'users','user_settings','password_resets','crops','livestock','expenses',
      'income','market_catalogue','notifications','admin_profiles','audit_log','sync_log'
    ];
    for (final t in tables) {
      final raw = _data[t];
      if (raw is! List) _data[t] = <dynamic>[];
    }
    // A safe fallback keeps the demo administrator available even if seed data was edited.
    final users = list('users');
    if (!users.any((u) => (u['email'] ?? '').toString().toLowerCase() == 'admin@agridata.local')) {
      users.add({
        'id': nextId('users'),
        'name': 'System Administrator',
        'phone': null,
        'email': 'admin@agridata.local',
        'password_hash': makeWerkzeugScryptHash('Admin@12345'),
        'language': 'English',
        'role': 'admin',
        'status': 'approved',
        'created_at': now(),
      });
      _data['users'] = users;
    }
  }

  List<Map<String, dynamic>> list(String table) =>
      (_data[table] as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();

  int nextId(String table) {
    final rows = list(table);
    var maxId = 0;
    for (final row in rows) {
      final id = int.tryParse('${row['id']}') ?? 0;
      if (id > maxId) maxId = id;
    }
    return maxId + 1;
  }

  Future<void> replace(String table, List<Map<String, dynamic>> rows) async {
    _data[table] = rows;
    await _save();
  }

  Future<void> add(String table, Map<String, dynamic> row) async {
    final rows = list(table)..add(row);
    await replace(table, rows);
  }

  Future<void> updateWhere(String table, int id, Map<String, dynamic> patch) async {
    final rows = list(table);
    for (var i = 0; i < rows.length; i++) {
      if (int.tryParse('${rows[i]['id']}') == id) rows[i] = {...rows[i], ...patch};
    }
    await replace(table, rows);
  }

  Future<void> deleteWhere(String table, int id) async {
    final rows = list(table)..removeWhere((r) => int.tryParse('${r['id']}') == id);
    await replace(table, rows);
  }

  Future<void> _save() async => _prefs.setString(_key, jsonEncode(_data));

  Future<void> setString(String key, String value) => _prefs.setString(key, value);
  Future<String?> getString(String key) => _prefs.getString(key);
  Future<void> remove(String key) => _prefs.remove(key);
}

String now() => DateTime.now().toIso8601String().split('.').first;
String today() => DateTime.now().toIso8601String().substring(0, 10);

bool validPhone(String value) => RegExp(r'^\d{10}$').hasMatch(value);
bool validPlantingDate(String? value) {
  if (value == null || value.isEmpty) return true;
  if (!RegExp(r'^\d{4}-\d{2}-\d{2}$').hasMatch(value)) return false;
  final d = DateTime.tryParse(value);
  return d != null && d.year.toString().padLeft(4, '0') == value.substring(0, 4);
}

String money(num value) {
  final fixed = value.toStringAsFixed(2);
  final parts = fixed.split('.');
  final whole = parts[0];
  final sign = whole.startsWith('-') ? '-' : '';
  final digits = sign.isEmpty ? whole : whole.substring(1);
  final buf = StringBuffer();
  for (var i = 0; i < digits.length; i++) {
    if (i > 0 && (digits.length - i) % 3 == 0) buf.write(',');
    buf.write(digits[i]);
  }
  return 'R $sign${buf.toString()}.${parts[1]}';
}

String makeWerkzeugScryptHash(String password) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  final rnd = Random.secure();
  final salt = List.generate(16, (_) => chars[rnd.nextInt(chars.length)]).join();
  final digest = scrypt(password.codeUnits, salt.codeUnits, N: 32768, r: 8, p: 1, dklen: 64).hex();
  return 'scrypt:32768:8:1\$$salt\$$digest';
}

bool verifyWerkzeugScrypt(String stored, String password) {
  final parts = stored.split('\$');
  if (parts.length != 3 || !parts[0].startsWith('scrypt:')) return false;
  final params = parts[0].split(':');
  if (params.length != 4) return false;
  final n = int.tryParse(params[1]);
  final r = int.tryParse(params[2]);
  final p = int.tryParse(params[3]);
  if (n == null || r == null || p == null) return false;
  final digest = scrypt(password.codeUnits, parts[1].codeUnits, N: n, r: r, p: p, dklen: 64).hex();
  return digest.toLowerCase() == parts[2].toLowerCase();
}

String translate(String language, String text) {
  if (language != 'isiZulu') return text;
  const z = {
    'Home': 'Ikhaya', 'Crops': 'Izilimo', 'Livestock': 'Imfuyo',
    'Purchases': 'Ukuthenga', 'Sales': 'Ukuthengisa', 'Reports': 'Imibiko',
    'Market Prices': 'Amanani Emakethe', 'Settings': 'Izilungiselelo',
    'Help / About': 'Usizo / Mayelana', 'Synchronization': 'Ukuvumelanisa',
    'Logout': 'Phuma', 'Login': 'Ngena', 'Register': 'Bhalisa',
    'Administrator': 'Umphathi', 'Farmer': 'Umlimi', 'Dashboard': 'Ideshibhodi',
    'Save': 'Gcina', 'Cancel': 'Khansela', 'Edit': 'Hlela', 'Delete': 'Susa',
    'Add Plant': 'Faka Isitshalo', 'Add Livestock': 'Faka Imfuyo',
    'Record Purchase': 'Rekhoda Ukuthenga', 'Record Sale': 'Rekhoda Ukuthengisa',
  };
  return z[text] ?? text;
}

class AppController extends ChangeNotifier {
  final LocalStore store;
  Map<String, dynamic>? currentUser;
  bool offlineMode = false;
  bool connected = true;
  Map<String, dynamic> settingsData = {'theme': 'light', 'accent': '#6b3f17', 'notifications': 1, 'compact_mode': 0};
  StreamSubscription<List<ConnectivityResult>>? _connectivity;

  AppController(this.store) {
    _listenConnectivity();
  }

  Future<void> restoreSession() async {
    final id = await store.getString('current_user_id');
    if (id == null) return;
    final userId = int.tryParse(id);
    if (userId == null) return;
    final user = store.list('users').where((u) => int.tryParse('${u['id']}') == userId).toList();
    if (user.isNotEmpty) {
      currentUser = user.first;
      settingsData = _settingsFor(userId);
    }
  }

  void _listenConnectivity() async {
    try {
      final c = Connectivity();
      final initial = await c.checkConnectivity();
      connected = initial.any((x) => x != ConnectivityResult.none);
      notifyListeners();
      _connectivity = c.onConnectivityChanged.listen((values) {
        connected = values.any((x) => x != ConnectivityResult.none);
        notifyListeners();
      });
    } catch (_) {}
  }

  String get language => '${currentUser?['language'] ?? 'English'}';

  String t(String value) => translate(language, value);
  Color get accent {
    final hex = '${settingsData['accent'] ?? '#6b3f17'}'.replaceAll('#', '');
    try { return Color(int.parse('FF$hex', radix: 16)); } catch (_) { return brown; }
  }
  ThemeMode get themeMode => settingsData['theme'] == 'dark' ? ThemeMode.dark : ThemeMode.light;

  Map<String, dynamic> _settingsFor(int uid) {
    final matches = store.list('user_settings').where((x) => int.tryParse('${x['user_id']}') == uid).toList();
    return matches.isEmpty ? {'theme':'light','accent':'#6b3f17','notifications':1,'compact_mode':0} : matches.first;
  }

  Future<void> _saveSession(Map<String, dynamic> user) async {
    currentUser = user;
    await store.setString('current_user_id', '${user['id']}');
    await store.replace('user_settings', _upsertSetting(_settingsFor(user['id'] as int), user['id'] as int));
    settingsData = _settingsFor(user['id'] as int);
    notifyListeners();
  }

  List<Map<String,dynamic>> _upsertSetting(Map<String,dynamic> setting, int uid) {
    final rows = store.list('user_settings');
    final index = rows.indexWhere((r) => int.tryParse('${r['user_id']}') == uid);
    final merged = {
      'user_id': uid,
      'theme': setting['theme'] ?? 'light',
      'accent': setting['accent'] ?? '#6b3f17',
      'notifications': setting['notifications'] ?? 1,
      'compact_mode': setting['compact_mode'] ?? 0,
    };
    if (index >= 0) rows[index] = {...rows[index], ...merged}; else rows.add(merged);
    return rows;
  }

  Future<String?> login(String identifier, String password, String role) async {
    final id = identifier.trim().toLowerCase();
    final users = store.list('users');
    final matches = users.where((u) => '${u['email'] ?? ''}'.toLowerCase() == id || '${u['phone'] ?? ''}'.toLowerCase() == id).toList();
    if (matches.isEmpty || !verifyWerkzeugScrypt('${matches.first['password_hash']}', password)) return 'Invalid email/phone or password.';
    final u = matches.first;
    if (!['auto','user','admin'].contains(role)) return 'Invalid login role.';
    if (role != 'auto' && '${u['role']}' != role) return 'This account is not registered for the selected role.';
    if ('${u['status']}' != 'approved') {
      if ('${u['status']}' == 'rejected') return 'Your registration request was rejected. Please contact the administrator.';
      return 'Your registration is waiting for administrator approval.';
    }
    await _saveSession(u);
    await store.setString('offline_user_id', '${u['id']}');
    await store.setString('offline_identifier_list', jsonEncode([if (u['email'] != null) '${u['email']}'.toLowerCase(), if (u['phone'] != null) '${u['phone']}'.toLowerCase()]));
    await store.setString('offline_password_hash', '${u['password_hash']}');
    return null;
  }

  Future<String?> offlineLogin(String identifier, String password) async {
    final savedId = await store.getString('offline_user_id');
    final savedHash = await store.getString('offline_password_hash');
    final idsRaw = await store.getString('offline_identifier_list');
    final identifiers = idsRaw == null ? <String>[] : List<String>.from(jsonDecode(idsRaw));
    if (savedId == null || savedHash == null || !identifiers.contains(identifier.trim().toLowerCase())) return 'Offline credentials do not match the saved account.';
    if (!verifyWerkzeugScrypt(savedHash, password)) return 'Invalid offline credentials.';
    final uid = int.tryParse(savedId);
    if (uid == null) return 'Saved offline account is invalid.';
    final user = store.list('users').where((u) => int.tryParse('${u['id']}') == uid).toList();
    if (user.isEmpty) return 'Saved offline account was not found.';
    currentUser = user.first;
    offlineMode = true;
    settingsData = _settingsFor(uid);
    notifyListeners();
    return null;
  }

  Future<String?> register({required String name, required String email, required String phone, required String password, required String language}) async {
    if (phone.isNotEmpty && !validPhone(phone)) return 'Phone number must contain exactly 10 digits.';
    if (name.trim().isEmpty || (email.trim().isEmpty && phone.trim().isEmpty) || password.length < 6) return 'Name, email or phone, and a password of at least 6 characters are required.';
    final users = store.list('users');
    if (users.any((u) => '${u['email'] ?? ''}'.toLowerCase() == email.trim().toLowerCase() || (phone.isNotEmpty && '${u['phone'] ?? ''}' == phone))) return 'That email or phone number is already registered.';
    final uid = store.nextId('users');
    await store.add('users', {
      'id': uid, 'name': name.trim(), 'phone': phone.isEmpty ? null : phone.trim(), 'email': email.trim().isEmpty ? null : email.trim().toLowerCase(),
      'password_hash': makeWerkzeugScryptHash(password), 'language': language, 'role':'user', 'status':'pending', 'created_at':now()
    });
    await store.add('user_settings', {'user_id':uid,'theme':'light','accent':'#6b3f17','notifications':1,'compact_mode':0});
    for (final admin in users.where((u) => '${u['role']}' == 'admin')) {
      await addNotification(int.tryParse('${admin['id']}') ?? 0, 'approval', 'New registration request', '$name has requested access to AgriData Hub.');
    }
    return null;
  }

  Future<void> logout() async {
    await store.remove('current_user_id');
    currentUser = null; offlineMode = false;
    notifyListeners();
  }

  Future<String?> requestPasswordReset(String identifier) async {
    final id = identifier.trim().toLowerCase();
    final user = store.list('users').where((u) => '${u['email'] ?? ''}'.toLowerCase() == id || '${u['phone'] ?? ''}'.toLowerCase() == id).toList();
    if (user.isEmpty) return null;
    final rnd = Random.secure();
    final code = (100000 + rnd.nextInt(900000)).toString();
    final reset = {'id':store.nextId('password_resets'),'user_id':user.first['id'],'code':code,'expires_at':DateTime.now().add(const Duration(minutes:15)).toIso8601String(),'used':0};
    await store.add('password_resets', reset);
    return code;
  }

  Future<String?> resetPassword(String identifier, String code, String password) async {
    if (password.length < 6) return 'New password must be at least 6 characters.';
    final id = identifier.trim().toLowerCase();
    final user = store.list('users').where((u) => '${u['email'] ?? ''}'.toLowerCase() == id || '${u['phone'] ?? ''}'.toLowerCase() == id).toList();
    if (user.isEmpty) return 'Account not found.';
    final rows = store.list('password_resets');
    final match = rows.lastWhereOrNull((r) => int.tryParse('${r['user_id']}') == int.tryParse('${user.first['id']}') && '${r['code']}' == code && '${r['used']}' == '0');
    if (match == null) return 'Invalid or expired reset code.';
    if (DateTime.tryParse('${match['expires_at']}')?.isBefore(DateTime.now()) ?? true) return 'Invalid or expired reset code.';
    await store.updateWhere('users', int.tryParse('${user.first['id']}')!, {'password_hash':makeWerkzeugScryptHash(password)});
    await store.updateWhere('password_resets', int.tryParse('${match['id']}')!, {'used':1});
    return null;
  }

  Future<void> updateProfile({required String name, required String email, required String phone}) async {
    final uid = int.tryParse('${currentUser?['id']}')!;
    await store.updateWhere('users', uid, {'name':name.trim(),'email':email.trim().toLowerCase().isEmpty?null:email.trim().toLowerCase(),'phone':phone.trim().isEmpty?null:phone.trim()});
    currentUser = store.list('users').firstWhere((u) => int.tryParse('${u['id']}') == uid);
    notifyListeners();
  }

  Future<void> updateLanguage(String value) async {
    final uid = int.tryParse('${currentUser?['id']}')!;
    await store.updateWhere('users', uid, {'language':value});
    currentUser = store.list('users').firstWhere((u) => int.tryParse('${u['id']}') == uid);
    notifyListeners();
  }

  Future<void> updateSettings(Map<String,dynamic> patch) async {
    final uid = int.tryParse('${currentUser?['id']}')!;
    settingsData = {...settingsData, ...patch};
    await store.replace('user_settings', _upsertSetting(settingsData, uid));
    notifyListeners();
  }

  List<Map<String,dynamic>> userRows(String table) {
    final uid = int.tryParse('${currentUser?['id']}') ?? -1;
    return store.list(table).where((r) => int.tryParse('${r['user_id']}') == uid).toList();
  }

  Future<void> addNotification(int uid, String kind, String title, String message) async {
    if (uid <= 0) return;
    await store.add('notifications', {'id':store.nextId('notifications'),'user_id':uid,'kind':kind,'title':title,'message':message,'is_read':0,'created_at':now()});
  }

  int get unreadNotifications {
    final uid = int.tryParse('${currentUser?['id']}') ?? -1;
    return store.list('notifications').where((r) => int.tryParse('${r['user_id']}') == uid && '${r['is_read']}' == '0').length;
  }

  Future<void> markNotificationsRead() async {
    final uid = int.tryParse('${currentUser?['id']}') ?? -1;
    final rows = store.list('notifications').map((r) => int.tryParse('${r['user_id']}') == uid ? {...r,'is_read':1} : r).toList();
    await store.replace('notifications', rows);
    notifyListeners();
  }

  Future<void> approveFarmer(int id) async {
    await store.updateWhere('users', id, {'status':'approved'});
    await addNotification(id, 'approval', 'Account approved', 'Your AgriData Hub farmer account has been approved. You can now log in.');
    notifyListeners();
  }
  Future<void> rejectFarmer(int id) async {
    await store.updateWhere('users', id, {'status':'rejected'});
    await addNotification(id, 'approval', 'Registration request update', 'Your AgriData Hub registration request was rejected. Please contact the administrator.');
    notifyListeners();
  }

  List<Map<String,dynamic>> adminUsers() => store.list('users').where((u) => ['admin','user'].contains('${u['role']}')).toList();

  Map<String,num> dashboardStats() {
    final crops = userRows('crops');
    final live = userRows('livestock');
    final inc = userRows('income');
    final exp = userRows('expenses');
    final incomeTotal = inc.fold<num>(0, (s, x) => s + num.tryParse('${x['amount'] ?? 0}')!);
    final expenseTotal = exp.fold<num>(0, (s, x) => s + num.tryParse('${x['amount'] ?? 0}')!);
    return {'crops':crops.length,'livestock':live.fold<num>(0,(s,x)=>s+num.tryParse('${x['quantity'] ?? 0}')!), 'income':incomeTotal,'expenses':expenseTotal,'profit':incomeTotal-expenseTotal};
  }

  int offlineQueueCount() {
    final uid = int.tryParse('${currentUser?['id']}') ?? -1;
    return store.list('sync_log').where((r) => int.tryParse('${r['user_id']}') == uid && '${r['status']}' == 'Pending').length;
  }

  Future<void> queueChange(String entity, String action, Map<String,dynamic> data) async {
    await store.add('sync_log', {'id':store.nextId('sync_log'),'user_id':currentUser?['id'],'synced_at':now(),'status':'Pending','entity':entity,'action':action,'data':jsonEncode(data)});
    notifyListeners();
  }

  Future<void> syncLocalQueue() async {
    final uid = int.tryParse('${currentUser?['id']}') ?? -1;
    final rows = store.list('sync_log').map((r) => int.tryParse('${r['user_id']}') == uid && '${r['status']}' == 'Pending' ? {...r,'status':'Success','synced_at':now()} : r).toList();
    await store.replace('sync_log', rows);
    notifyListeners();
  }
}

extension LastWhereOrNull<E> on Iterable<E> {
  E? lastWhereOrNull(bool Function(E element) test) {
    for (final element in reversed.toList()) { if (test(element)) return element; }
    return null;
  }
}

class AgriDataHubApp extends StatelessWidget {
  final AppController controller;
  const AgriDataHubApp({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'AgriData Hub',
        themeMode: controller.themeMode,
        theme: ThemeData(useMaterial3: true, colorSchemeSeed: controller.accent, brightness: Brightness.light, scaffoldBackgroundColor: const Color(0xFFF8F5EF)),
        darkTheme: ThemeData(useMaterial3: true, colorSchemeSeed: controller.accent, brightness: Brightness.dark),
        home: controller.currentUser == null ? AuthPage(controller) : HomeShell(controller),
      ),
    );
  }
}

class AuthPage extends StatefulWidget {
  final AppController controller;
  const AuthPage(this.controller, {super.key});
  @override State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  int mode = 0;
  final loginId = TextEditingController();
  final loginPassword = TextEditingController();
  final registerName = TextEditingController();
  final registerEmail = TextEditingController();
  final registerPhone = TextEditingController();
  final registerPassword = TextEditingController();
  final forgotId = TextEditingController();
  final resetCode = TextEditingController();
  final newPassword = TextEditingController();
  String role = 'auto'; String language = 'English'; String? devCode;

  @override void dispose() { for (final c in [loginId,loginPassword,registerName,registerEmail,registerPhone,registerPassword,forgotId,resetCode,newPassword]) c.dispose(); super.dispose(); }

  void snack(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.sizeOf(context).width >= 720;
    return Scaffold(
      body: SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 520), child: Card(elevation: 4, child: Padding(padding: const EdgeInsets.all(28), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(mainAxisAlignment: MainAxisAlignment.center, children: const [Text('🌱',style:TextStyle(fontSize:40)),Text('🐄',style:TextStyle(fontSize:40))]),
        const SizedBox(height: 8),
        const Text('AgriData Hub', textAlign: TextAlign.center, style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800)),
        const SizedBox(height: 4), const Text('Smart Data. Stronger Farms.', textAlign: TextAlign.center),
        const SizedBox(height: 18),
        const NoticeCard(text:'🌱🐄 Farmers register for approval. Administrators manage farmer accounts and approvals.'),
        const SizedBox(height: 18),
        SegmentedButton<int>(segments: const [ButtonSegment(value:0,label:Text('Login'),icon:Icon(Icons.login)),ButtonSegment(value:1,label:Text('Register'),icon:Icon(Icons.person_add)),ButtonSegment(value:2,label:Text('Forgot'),icon:Icon(Icons.lock_reset))], selected:{mode}, onSelectionChanged:(s)=>setState(()=>mode=s.first)),
        const SizedBox(height: 18),
        if (mode==0) _loginForm(wide) else if(mode==1) _registerForm() else _forgotForm(),
      ])))))));
  }

  Widget _field(TextEditingController c,String label,{bool password=false,TextInputType? type,String? hint,int? maxLength,List<TextInputFormatter>? formatters}) => Padding(padding:const EdgeInsets.only(bottom:12),child:TextField(controller:c,obscureText:password,keyboardType:type,inputFormatters:formatters,maxLength:maxLength,decoration:InputDecoration(labelText:label,hintText:hint,border:const OutlineInputBorder(),counterText:'')));

  Widget _loginForm(bool wide) => Column(children: [
    DropdownButtonFormField<String>(value:role,decoration:const InputDecoration(labelText:'Login as',border:OutlineInputBorder()),items:const [DropdownMenuItem(value:'auto',child:Text('Select automatically')),DropdownMenuItem(value:'user',child:Text('👨🏾‍🌾 Farmer / User')),DropdownMenuItem(value:'admin',child:Text('🛡️ Administrator'))],onChanged:(v)=>setState(()=>role=v!)),
    const SizedBox(height:12), _field(loginId,'Email or phone',hint:'Email address or phone number'), _field(loginPassword,'Password',password:true,hint:'Password'),
    FilledButton.icon(onPressed:()async{final e=await widget.controller.login(loginId.text,loginPassword.text,role);if(e!=null){snack(e);}else{snack('Login successful');setState((){});}},icon:const Icon(Icons.login),label:const Text('Login')),
    const SizedBox(height:8), OutlinedButton.icon(onPressed:()=>_showOfflineDialog(),icon:const Icon(Icons.wifi_off),label:const Text('Login Offline')),
  ]);

  Widget _registerForm() => Column(children: [
    _field(registerName,'Full name'), _field(registerEmail,'Email address',type:TextInputType.emailAddress), _field(registerPhone,'Phone number',type:TextInputType.phone,maxLength:10,formatters:[FilteringTextInputFormatter.digitsOnly]),
    Align(alignment:Alignment.centerLeft,child:Text('Use at least one: email or phone number. Phone must contain exactly 10 digits.',style:Theme.of(context).textTheme.bodySmall)), const SizedBox(height:12),
    _field(registerPassword,'Password',password:true,hint:'At least 6 characters'),
    DropdownButtonFormField<String>(value:language,decoration:const InputDecoration(labelText:'Preferred language',border:OutlineInputBorder()),items:const [DropdownMenuItem(value:'English',child:Text('English')),DropdownMenuItem(value:'isiZulu',child:Text('isiZulu'))],onChanged:(v)=>setState(()=>language=v!)),
    const SizedBox(height:12),
    FilledButton.icon(onPressed:()async{final e=await widget.controller.register(name:registerName.text,email:registerEmail.text,phone:registerPhone.text,password:registerPassword.text,language:language);if(e!=null){snack(e);}else{snack('Registration submitted. An administrator must approve your account before you can log in.');setState(()=>mode=0);}},icon:const Icon(Icons.person_add),label:const Text('Register')),
  ]);

  Widget _forgotForm() => Column(children: [
    _field(forgotId,'Email or phone'),
    FilledButton.icon(onPressed:()async{devCode=await widget.controller.requestPasswordReset(forgotId.text);setState((){});if(devCode==null)snack('If an account matches, a reset code has been prepared.');else snack('Development reset code: $devCode');},icon:const Icon(Icons.send),label:const Text('Send reset code')),
    if(devCode!=null)...[const SizedBox(height:16),const NoticeCard(text:'Development build: the reset code is shown here because no email/SMS service is configured.'),const SizedBox(height:12),_field(resetCode,'Reset code',maxLength:6,type:TextInputType.number,formatters:[FilteringTextInputFormatter.digitsOnly]),_field(newPassword,'New password',password:true),FilledButton.icon(onPressed:()async{final e=await widget.controller.resetPassword(forgotId.text,resetCode.text,newPassword.text);if(e!=null)snack(e);else{snack('Password changed. You can now log in.');setState(()=>mode=0);}},icon:const Icon(Icons.check),label:const Text('Change password'))]
  ]);

  void _showOfflineDialog(){
    final id = TextEditingController(); final pw = TextEditingController();
    showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('Offline Login'),content:Column(mainAxisSize:MainAxisSize.min,children:[const Text('Enter the same account credentials used for your last successful login.'),const SizedBox(height:12),TextField(controller:id,decoration:const InputDecoration(labelText:'Email or phone',border:OutlineInputBorder())),const SizedBox(height:10),TextField(controller:pw,obscureText:true,decoration:const InputDecoration(labelText:'Password',border:OutlineInputBorder()))]),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Cancel')),FilledButton(onPressed:()async{final e=await widget.controller.offlineLogin(id.text,pw.text);if(e!=null)snack(e);else{Navigator.pop(context);setState((){});}},child:const Text('Login Offline'))]));
  }
}

class NoticeCard extends StatelessWidget { final String text; const NoticeCard({super.key,required this.text}); @override Widget build(BuildContext c)=>Container(padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:Theme.of(c).colorScheme.primaryContainer,borderRadius:BorderRadius.circular(12)),child:Text(text)); }

class HomeShell extends StatefulWidget {
  final AppController controller;
  const HomeShell(this.controller,{super.key});
  @override State<HomeShell> createState()=>_HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  String page='dashboard';
  final GlobalKey<ScaffoldState> scaffoldKey=GlobalKey<ScaffoldState>();
  AppController get c=>widget.controller;
  bool get admin=> '${c.currentUser?['role']}'=='admin';

  List<_NavItem> get nav => admin ? [
    _NavItem('admin','Admin Dashboard',Icons.shield),_NavItem('adminUsers','User Management',Icons.people),_NavItem('settings','Settings',Icons.settings),_NavItem('sync','Synchronization',Icons.sync),_NavItem('help','Help / About',Icons.help_outline)
  ] : [
    _NavItem('dashboard','Home',Icons.home),_NavItem('crops','Crops',Icons.grass),_NavItem('livestock','Livestock',Icons.pets),_NavItem('expenses','Purchases',Icons.shopping_cart),_NavItem('income','Sales',Icons.attach_money),_NavItem('reports','Reports',Icons.bar_chart),_NavItem('market','Market Prices',Icons.storefront),_NavItem('sync','Synchronization',Icons.sync),_NavItem('settings','Settings',Icons.settings),_NavItem('help','Help / About',Icons.help_outline)
  ];

  @override Widget build(BuildContext context) {
    final wide=MediaQuery.sizeOf(context).width>=1000;
    return Scaffold(
      key: scaffoldKey,
      drawer: wide?null:_buildDrawer(),
      appBar: AppBar(title:Row(children:[const Text('🌱🐄 '),Text.rich(TextSpan(text:'AgriData ',children:[TextSpan(text:'Hub',style:TextStyle(fontWeight:FontWeight.bold))]))]),actions:[ConnectivityBadge(connected:c.connected,offline:c.offlineMode),IconButton(onPressed:_notifications,icon:Badge(isLabelVisible:c.unreadNotifications>0,label:Text('${c.unreadNotifications}'),child:const Icon(Icons.notifications_none))),if(!wide)IconButton(onPressed:()=>scaffoldKey.currentState?.openDrawer(),icon:const Icon(Icons.menu))]),
      body: wide ? Row(children:[SizedBox(width:250,child:_rail()),const VerticalDivider(width:1),Expanded(child:_body())]) : _body(),
      bottomNavigationBar: wide?null:_bottomNavigation(),
    );
  }

  Widget _rail()=>Material(color:Theme.of(context).colorScheme.surface,child:ListView(padding:const EdgeInsets.symmetric(vertical:12),children:[for(final n in nav)ListTile(selected:page==n.id,leading:Icon(n.icon),title:Text(c.t(n.label)),onTap:(){setState(()=>page=n.id);}) ,const Divider(),ListTile(leading:const Icon(Icons.logout,color:red),title:Text('Logout'),onTap:_logout)]));
  Drawer _buildDrawer()=>Drawer(child:SafeArea(child:ListView(children:[const DrawerHeader(child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Text('🌱🐄',style:TextStyle(fontSize:42)),Text('AgriData Hub',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold))])),for(final n in nav)ListTile(selected:page==n.id,leading:Icon(n.icon),title:Text(c.t(n.label)),onTap:(){Navigator.pop(context);setState(()=>page=n.id);}),const Divider(),ListTile(leading:const Icon(Icons.logout,color:red),title:Text(c.t('Logout')),onTap:_logout)])));
  Widget _bottomNavigation(){
    final items=admin?nav.take(4).toList():[nav[0],nav[1],nav[2],nav[5],_NavItem('more','More',Icons.more_horiz)];
    final selectedRaw=items.indexWhere((x)=>x.id==page);
    final selected=selectedRaw<0?0:selectedRaw;
    return NavigationBar(selectedIndex:selected,onDestinationSelected:(i){final item=items[i];if(item.id=='more'){scaffoldKey.currentState?.openDrawer();}else setState(()=>page=item.id);},destinations:[for(final n in items)NavigationDestination(icon:Icon(n.icon),label:c.t(n.label))]);
  }
  Widget _body(){switch(page){case 'dashboard':return FarmerDashboardPage(c);case 'crops':return CropsPage(c);case 'livestock':return LivestockPage(c);case 'expenses':return ExpensesPage(c);case 'income':return IncomePage(c);case 'reports':return ReportsPage(c);case 'market':return MarketPage(c);case 'sync':return SyncPage(c);case 'settings':return SettingsPage(c);case 'help':return HelpPage(c);case 'admin':return AdminDashboardPage(c);case 'adminUsers':return AdminUsersPage(c);default:return FarmerDashboardPage(c);}}
  Future<void> _logout() async {await c.logout();}
  void _notifications() async {final items=c.userRows('notifications');await showModalBottomSheet(context:context,isScrollControlled:true,builder:(_)=>SizedBox(height:MediaQuery.sizeOf(context).height*.75,child:Padding(padding:const EdgeInsets.all(20),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[Text(c.t('Notifications'),style:Theme.of(context).textTheme.headlineSmall),const SizedBox(height:12),Expanded(child:items.isEmpty?const Center(child:Text('No notifications yet.')):ListView.separated(itemCount:items.length,itemBuilder:(_,i){final n=items[i];return ListTile(tileColor:'${n['is_read']}'=='0'?Theme.of(context).colorScheme.secondaryContainer:null,leading:const Icon(Icons.notifications),title:Text('${n['title']}'),subtitle:Text('${n['message']}\n${n['created_at']}'));},separatorBuilder:(_,__)=>const Divider())),TextButton(onPressed:(){c.markNotificationsRead();Navigator.pop(context);},child:const Text('Mark all as read'))])));}
}
class _NavItem { final String id,label; final IconData icon; _NavItem(this.id,this.label,this.icon); }
class ConnectivityBadge extends StatelessWidget { final bool connected,offline; const ConnectivityBadge({super.key,required this.connected,required this.offline}); @override Widget build(BuildContext c){final text=offline?'🔴 Offline Mode':(connected?'🟢 Online':'🟠 No Internet');return Padding(padding:const EdgeInsets.symmetric(horizontal:8),child:Chip(label:Text(text)));}}

class PageFrame extends StatelessWidget { final AppController c; final String title,subtitle; final Widget child; final Widget? action; const PageFrame({super.key,required this.c,required this.title,required this.subtitle,required this.child,this.action}); @override Widget build(BuildContext context)=>SingleChildScrollView(padding:const EdgeInsets.all(18),child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:1200),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[Row(crossAxisAlignment:CrossAxisAlignment.start,children:[Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(c.t(title),style:Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight:FontWeight.w800)),const SizedBox(height:3),Text(subtitle,style:Theme.of(context).textTheme.bodyMedium)])),if(action!=null)action!]),const SizedBox(height:16),child])); }

class StatCard extends StatelessWidget { final String icon,label,value; final Color? color; const StatCard({super.key,required this.icon,required this.label,required this.value,this.color}); @override Widget build(BuildContext context)=>Card(child:Padding(padding:const EdgeInsets.all(16),child:Row(children:[Text(icon,style:const TextStyle(fontSize:28)),const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(label,style:Theme.of(context).textTheme.bodySmall),const SizedBox(height:4),Text(value,style:Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight:FontWeight.w800,color:color))]))])); }

class FarmerDashboardPage extends StatelessWidget { final AppController c; const FarmerDashboardPage(this.c,{super.key}); @override Widget build(BuildContext context){final d=c.dashboardStats();final inc=d['income']??0,exp=d['expenses']??0,profit=d['profit']??0;final incomeRows=c.userRows('income');final expenseRows=c.userRows('expenses');final recent=[...incomeRows.map((x)=>{'title':'${x['item']}','date':'${x['sale_date']}','value':'+${money(num.tryParse('${x['amount']}')??0)}','icon':'💰'}),...expenseRows.map((x)=>{'title':'${x['description']}','date':'${x['expense_date']}','value':'-${money(num.tryParse('${x['amount']}')??0)}','icon':'🛒'})];recent.sort((a,b)=>'${b['date']}'.compareTo('${a['date']}'));final r=recent.take(8).toList();return PageFrame(c:c,title:'Farmer Dashboard',subtitle:'Welcome, ${c.currentUser?['name'] ?? 'Farmer'} 👋',child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[Card(child:Padding(padding:const EdgeInsets.all(18),child:Row(children:[Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Your farm at a glance',style:Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight:FontWeight.bold)),const SizedBox(height:4),const Text('Manage plants, livestock and finances in one place.'),const SizedBox(height:16),Wrap(spacing:8,runSpacing:8,children:[Chip(label:Text(c.offlineMode?'Offline mode active':(c.connected?'Online':'No internet'))),Chip(label:Text('🌾 🏠 🐄'))])]),const Text('🌾🏠🐄',style:TextStyle(fontSize:48))]))),const SizedBox(height:8),GridView.count(crossAxisCount:MediaQuery.sizeOf(context).width>900?5:2,shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisSpacing:10,mainAxisSpacing:10,childAspectRatio:2.1,children:[StatCard(icon:'🌿',label:'Total Crops',value:'${d['crops']}'),StatCard(icon:'🐄',label:'Total Livestock',value:'${d['livestock']}'),StatCard(icon:'💰',label:'Income',value:money(inc),color:green),StatCard(icon:'🛒',label:'Purchases',value:money(exp),color:red),StatCard(icon:'📈',label:'Profit',value:money(profit),color:profit>=0?green:red)]),const SizedBox(height:16),Text('Quick Actions',style:Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight:FontWeight.bold)),const SizedBox(height:8),Wrap(spacing:10,runSpacing:10,children:[_QuickButton(icon:Icons.grass,label:'Add Plant',onTap:()=>_openPlant(context,c)),_QuickButton(icon:Icons.pets,label:'Add Livestock',onTap:()=>_openLivestock(context,c)),_QuickButton(icon:Icons.shopping_cart,label:'Add Purchase',onTap:()=>_openExpense(context,c)),_QuickButton(icon:Icons.attach_money,label:'Record Sale',onTap:()=>_openIncome(context,c))]),const SizedBox(height:16),Text('Recent Activity',style:Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight:FontWeight.bold)),const SizedBox(height:8),Card(child:r.isEmpty?const Padding(padding:EdgeInsets.all(18),child:Text('No activity recorded yet.')):Column(children:[for(var i=0;i<r.length;i++)ListTile(leading:CircleAvatar(child:Text('${r[i]['icon']}')),title:Text('${r[i]['title']}'),subtitle:Text('${r[i]['date']}'),trailing:Text('${r[i]['value']}',style:const TextStyle(fontWeight:FontWeight.w700)),dense:true,contentPadding:const EdgeInsets.symmetric(horizontal:16),)]) )]));}}
class _QuickButton extends StatelessWidget { final IconData icon; final String label; final VoidCallback onTap; const _QuickButton({required this.icon,required this.label,required this.onTap}); @override Widget build(BuildContext c)=>FilledButton.tonalIcon(onPressed:onTap,icon:Icon(icon),label:Text(label)); }

class CropsPage extends StatefulWidget { final AppController c; const CropsPage(this.c,{super.key}); @override State<CropsPage> createState()=>_CropsPageState(); }
class _CropsPageState extends State<CropsPage>{ Future<void> add([Map<String,dynamic>? existing])=>_openPlant(context,widget.c,existing).then((_)=>setState((){})); @override Widget build(BuildContext context){final rows=widget.c.userRows('crops')..sort((a,b)=>'${b['created_at']}'.compareTo('${a['created_at']}'));return PageFrame(c:widget.c,title:'Plant Management',subtitle:'Track crops and planting areas.',action:FilledButton.icon(onPressed:()=>add(),icon:const Icon(Icons.add),label:Text(widget.c.t('Add Plant'))),child:rows.isEmpty?const EmptyCard(text:'No plant records.'):Column(children:[for(final x in rows)Card(child:ListTile(leading:CircleAvatar(child:Text('${x['icon']??'🌱'}')),title:Text('${x['name']}'),subtitle:Text('Planted: ${x['planting_date']??'—'} · Area: ${x['area'] ?? 0} ha'),trailing:Wrap(children:[IconButton(onPressed:()=>add(x),icon:const Icon(Icons.edit)),IconButton(onPressed:()=>_deleteRow(context,widget.c,'crops',x),icon:const Icon(Icons.delete,color:red))]))])]);}}

class LivestockPage extends StatefulWidget { final AppController c; const LivestockPage(this.c,{super.key}); @override State<LivestockPage> createState()=>_LivestockPageState(); }
class _LivestockPageState extends State<LivestockPage>{ Future<void> add()=>_openLivestock(context,widget.c).then((_)=>setState((){})); @override Widget build(BuildContext context){final icons={'Cattle':'🐄','Goats':'🐐','Chickens':'🐔','Sheep':'🐑','Pigs':'🐖','Rabbits':'🐇'};final rows=widget.c.userRows('livestock')..sort((a,b)=>'${b['record_date']}'.compareTo('${a['record_date']}'));return PageFrame(c:widget.c,title:'Livestock Management',subtitle:'Record animals, births and sales.',action:FilledButton.icon(onPressed:add,icon:const Icon(Icons.add),label:Text(widget.c.t('Add Livestock'))),child:rows.isEmpty?const EmptyCard(text:'No livestock records.'):Column(children:[for(final x in rows)Card(child:ListTile(leading:CircleAvatar(child:Text(icons['${x['animal_type']}']??'🐄')),title:Text('${x['animal_type']}'),subtitle:Text('${x['quantity']} · ${x['record_type']} · ${x['record_date']}'),trailing:IconButton(onPressed:()=>_deleteRow(context,widget.c,'livestock',x),icon:const Icon(Icons.delete,color:red)))]));}}

class ExpensesPage extends StatefulWidget { final AppController c; const ExpensesPage(this.c,{super.key}); @override State<ExpensesPage> createState()=>_ExpensesPageState(); }
class _ExpensesPageState extends State<ExpensesPage>{ Future<void> add()=>_openExpense(context,widget.c).then((_)=>setState((){})); @override Widget build(BuildContext context){final rows=widget.c.userRows('expenses')..sort((a,b)=>'${b['expense_date']}'.compareTo('${a['expense_date']}'));final total=rows.fold<num>(0,(s,x)=>s+(num.tryParse('${x['amount'] ?? 0}')??0));return PageFrame(c:widget.c,title:'Purchases / Expenses',subtitle:'Record farm purchases and expenses.',action:FilledButton.icon(onPressed:add,icon:const Icon(Icons.add),label:Text(widget.c.t('Record Purchase'))),child:Column(children:[Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Total Purchases'),const SizedBox(height:5),Text(money(total),style:Theme.of(context).textTheme.headlineSmall?.copyWith(color:red,fontWeight:FontWeight.w800))]))),const SizedBox(height:12),Align(alignment:Alignment.centerLeft,child:Text('Purchase History',style:Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight:FontWeight.bold))),const SizedBox(height:8),rows.isEmpty?const EmptyCard(text:'No purchases recorded.'):Column(children:[for(final x in rows)Card(child:ListTile(leading:const CircleAvatar(child:Text('🛒')),title:Text('${x['description']}'),subtitle:Text('${x['category']} · ${x['expense_date']}'),trailing:Wrap(spacing:4,children:[Text(money(num.tryParse('${x['amount']}')??0),style:const TextStyle(fontWeight:FontWeight.bold)),IconButton(onPressed:()=>_deleteRow(context,widget.c,'expenses',x),icon:const Icon(Icons.delete,color:red))]))])]);}));}}

class IncomePage extends StatefulWidget { final AppController c; const IncomePage(this.c,{super.key}); @override State<IncomePage> createState()=>_IncomePageState(); }
class _IncomePageState extends State<IncomePage>{ Future<void> add()=>_openIncome(context,widget.c).then((_)=>setState((){})); @override Widget build(BuildContext context){final rows=widget.c.userRows('income')..sort((a,b)=>'${b['sale_date']}'.compareTo('${a['sale_date']}'));final total=rows.fold<num>(0,(s,x)=>s+(num.tryParse('${x['amount'] ?? 0}')??0));return PageFrame(c:widget.c,title:'Sales / Income',subtitle:'Record farm sales.',action:FilledButton.icon(onPressed:add,icon:const Icon(Icons.add),label:Text(widget.c.t('Record Sale'))),child:Column(children:[Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Total Income'),const SizedBox(height:5),Text(money(total),style:Theme.of(context).textTheme.headlineSmall?.copyWith(color:green,fontWeight:FontWeight.w800))]))),const SizedBox(height:12),Align(alignment:Alignment.centerLeft,child:Text('Sales History',style:Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight:FontWeight.bold))),const SizedBox(height:8),rows.isEmpty?const EmptyCard(text:'No sales recorded.'):Column(children:[for(final x in rows)Card(child:ListTile(leading:const CircleAvatar(child:Text('💰')),title:Text('${x['item']}'),subtitle:Text('${x['quantity']??''} · ${x['sale_date']}'),trailing:Wrap(spacing:4,children:[Text(money(num.tryParse('${x['amount']}')??0),style:const TextStyle(fontWeight:FontWeight.bold)),IconButton(onPressed:()=>_deleteRow(context,widget.c,'income',x),icon:const Icon(Icons.delete,color:red))]))])]);}));}}

class ReportsPage extends StatelessWidget { final AppController c; const ReportsPage(this.c,{super.key}); @override Widget build(BuildContext context){final d=c.dashboardStats();return PageFrame(c:c,title:'Reports',subtitle:'Farm performance overview.',child:Column(children:[Row(crossAxisAlignment:CrossAxisAlignment.start,children:[Expanded(child:Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[const Text('Income vs Purchases',style:TextStyle(fontWeight:FontWeight.bold)),const SizedBox(height:18),SizedBox(height:240,child:BarSummary(values:[num.tryParse('${d['income']}')??0,num.tryParse('${d['expenses']}')??0,num.tryParse('${d['profit']}')??0],labels:const ['Income','Purchases','Profit']))]))),const SizedBox(width:12),Expanded(child:Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Profit',style:TextStyle(fontWeight:FontWeight.bold)),const SizedBox(height:18),Text(money(num.tryParse('${d['profit']}')??0),style:Theme.of(context).textTheme.headlineMedium?.copyWith(color:(num.tryParse('${d['profit']}')??0)>=0?green:red,fontWeight:FontWeight.w800)),const SizedBox(height:8),const Text('Income minus purchases.')]))))]),const SizedBox(height:12),_ReportList(title:'Crops',rows:c.userRows('crops').map((x)=>'${x['name']} · ${x['area']??0} ha · ${x['planting_date']??'—'}').toList()),_ReportList(title:'Livestock',rows:_groupLivestock(c).map((e)=>'${e.key}: ${e.value}').toList())]));}}
Map<String,num> _groupLivestock(AppController c){final out=<String,num>{};for(final x in c.userRows('livestock')){final k='${x['animal_type']}';out[k]=(out[k]??0)+(num.tryParse('${x['quantity']??0}')??0);}return out;}
class BarSummary extends StatelessWidget { final List<num> values; final List<String> labels; const BarSummary({super.key,required this.values,required this.labels}); @override Widget build(BuildContext context){final maxVal=values.fold<num>(1,(m,v)=>v.abs()>m?v.abs():m);return Row(crossAxisAlignment:CrossAxisAlignment.end,mainAxisAlignment:MainAxisAlignment.spaceEvenly,children:[for(var i=0;i<values.length;i++)Expanded(child:Padding(padding:const EdgeInsets.symmetric(horizontal:8),child:Column(mainAxisAlignment:MainAxisAlignment.end,children:[Text(money(values[i]),style:Theme.of(context).textTheme.labelSmall),const SizedBox(height:6),AnimatedContainer(duration:const Duration(milliseconds:500),height:170*(values[i].abs()/maxVal),decoration:BoxDecoration(color:values[i]>=0?Theme.of(context).colorScheme.primary:Theme.of(context).colorScheme.error,borderRadius:BorderRadius.circular(10))),const SizedBox(height:6),Text(labels[i])])))]);}}
class _ReportList extends StatelessWidget {final String title;final List<String> rows;const _ReportList({required this.title,required this.rows});@override Widget build(BuildContext c)=>Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontWeight:FontWeight.bold)),const SizedBox(height:8),if(rows.isEmpty)const Text('No records.') else for(final r in rows)ListTile(dense:true,title:Text(r),leading:const Icon(Icons.chevron_right))])));}

class MarketPage extends StatefulWidget { final AppController c; const MarketPage(this.c,{super.key}); @override State<MarketPage> createState()=>_MarketPageState(); }
class _MarketPageState extends State<MarketPage>{ Future<void> add([Map<String,dynamic>? existing])=>_openMarket(context,widget.c,existing).then((_)=>setState((){})); @override Widget build(BuildContext context){final rows=widget.c.userRows('market_catalogue')..sort((a,b)=>'${a['product']}'.toLowerCase().compareTo('${b['product']}'.toLowerCase()));return PageFrame(c:widget.c,title:'🏪 Market Price Catalogue',subtitle:'Set and manage the prices you want to use for your farm products.',action:FilledButton.icon(onPressed:()=>add(),icon:const Icon(Icons.add),label:Text(widget.c.t('Add Price'))),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[const NoticeCard(text:'Your catalogue is private to your farmer account. You can update prices whenever market conditions change.'),const SizedBox(height:14),Text('My Price Catalogue',style:Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight:FontWeight.bold)),const SizedBox(height:8),rows.isEmpty?const EmptyCard(text:'No prices in your catalogue yet. Add your first product price.'):Column(children:[for(final x in rows)Card(child:ListTile(leading:CircleAvatar(child:Text('${x['category']}'=='Livestock'?'🐄':'🌱')),title:Text('${x['product']}'),subtitle:Text('${x['category']} · per ${x['unit']}${'${x['notes']}'.isNotEmpty?' · ${x['notes']}':''}'),trailing:Column(mainAxisAlignment:MainAxisAlignment.center,crossAxisAlignment:CrossAxisAlignment.end,children:[Text(money(num.tryParse('${x['price']}')??0),style:const TextStyle(fontWeight:FontWeight.w800)),Wrap(children:[IconButton(onPressed:()=>add(x),icon:const Icon(Icons.edit)),IconButton(onPressed:()=>_deleteRow(context,widget.c,'market_catalogue',x),icon:const Icon(Icons.delete,color:red))])]))])])]);}}

class SyncPage extends StatelessWidget { final AppController c; const SyncPage(this.c,{super.key}); @override Widget build(BuildContext context){final pending=c.offlineQueueCount();final last=c.store.list('sync_log').where((r)=>int.tryParse('${r['user_id']}')==int.tryParse('${c.currentUser?['id']}') && '${r['status']}'!='Pending').toList();last.sort((a,b)=>'${b['synced_at']}'.compareTo('${a['synced_at']}'));return PageFrame(c:c,title:'Synchronization',subtitle:'Offline records are saved on this device and can be processed when you reconnect.',child:Card(child:Padding(padding:const EdgeInsets.all(20),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[const Text('☁️🔄',style:TextStyle(fontSize:44)),const SizedBox(height:8),Chip(label:Text('Local-first Flutter storage')),const SizedBox(height:8),Text('Pending offline changes: $pending'),const SizedBox(height:4),Text('Last synchronization: ${last.isEmpty?'Not available':'${last.first['synced_at']}'}'),const SizedBox(height:18),FilledButton.icon(onPressed:pending==0?null:()async{await c.syncLocalQueue();},icon:const Icon(Icons.sync),label:Text(pending==0?'Sync Now':'Reconnect & Sync')),const SizedBox(height:12),const NoticeCard(text:'This Flutter edition no longer depends on the Flask server. A remote cloud sync connector can be attached later without changing the screen structure.')])))];}}

class SettingsPage extends StatefulWidget { final AppController c; const SettingsPage(this.c,{super.key}); @override State<SettingsPage> createState()=>_SettingsPageState(); }
class _SettingsPageState extends State<SettingsPage>{@override Widget build(BuildContext context){final c=widget.c; final me=c.currentUser!;return PageFrame(c:c,title:'Settings',subtitle:'Profile, appearance, notifications and app preferences.',child:Column(children:[Card(child:Column(children:[ListTile(leading:const Icon(Icons.person),title:const Text('Profile'),subtitle:Text('${me['name']} · ${me['email']??me['phone']??''}'),trailing:FilledButton.tonal(onPressed:()=>_profile(context,c),child:Text(c.t('Edit')))),const Divider(height:1),ListTile(leading:const Icon(Icons.palette),title:const Text('App colour'),trailing:DropdownButton<String>(value:'${c.settingsData['accent']??'#6b3f17'}',items:const ['#6b3f17','#2e7d32','#8e44ad','#1565c0','#bf360c'].map((v)=>DropdownMenuItem(value:v,child:Container(width:22,height:22,color:Color(int.parse('FF${v.substring(1)}',radix:16))))).toList(),onChanged:(v)async{await c.updateSettings({'accent':v});setState((){});})),SwitchListTile(title:const Text('Dark mode'),value:c.settingsData['theme']=='dark',onChanged:(v)async{await c.updateSettings({'theme':v?'dark':'light'});setState((){});}),SwitchListTile(title:const Text('Notifications'),value:'${c.settingsData['notifications']}'!='0',onChanged:(v)async{await c.updateSettings({'notifications':v?1:0});setState((){});}),SwitchListTile(title:const Text('Compact layout'),value:'${c.settingsData['compact_mode']}'!='0',onChanged:(v)async{await c.updateSettings({'compact_mode':v?1:0});setState((){});}),ListTile(leading:const Icon(Icons.language),title:const Text('Language'),trailing:DropdownButton<String>(value:'${me['language']??'English'}',items:const [DropdownMenuItem(value:'English',child:Text('English')),DropdownMenuItem(value:'isiZulu',child:Text('isiZulu'))],onChanged:(v)async{await c.updateLanguage(v!);setState((){});})),])),Card(child:ListTile(leading:const Icon(Icons.logout,color:red),title:Text(c.t('Logout')),onTap:()async=>c.logout()))]));}}
class HelpPage extends StatelessWidget { final AppController c; const HelpPage(this.c,{super.key}); @override Widget build(BuildContext context)=>PageFrame(c:c,title:'Help & About',subtitle:'AgriData Hub supports farmers and administrators.',child:Column(children:[const NoticeCard(text:'AgriData Hub is now a Flutter application for Android, iOS and Web.'),const SizedBox(height:12),Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Cross-platform access',style:Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight:FontWeight.bold)),const SizedBox(height:6),const Text('One Flutter codebase is used for the web and mobile applications. Data is stored locally first so the core farming workflows remain available without the original Flask server.'),const SizedBox(height:14),Text('Production note',style:Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight:FontWeight.bold)),const SizedBox(height:6),const Text('For shared multi-device data, connect the repository layer to a cloud backend such as Firebase, Supabase or a Dart API.')])),]));}}

class AdminDashboardPage extends StatelessWidget { final AppController c; const AdminDashboardPage(this.c,{super.key}); @override Widget build(BuildContext context){final users=c.adminUsers();final farmers=users.where((u)=>'${u['role']}'=='user').toList();final pending=farmers.where((u)=>'${u['status']}'=='pending').length;final approved=farmers.where((u)=>'${u['status']}'=='approved').length;final rejected=farmers.where((u)=>'${u['status']}'=='rejected').length;final admins=users.where((u)=>'${u['role']}'=='admin').length;return PageFrame(c:c,title:'🛡️ Administrator Dashboard',subtitle:'Manage farmer registrations, account status and system administration.',child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[Wrap(spacing:10,runSpacing:10,children:[SizedBox(width:210,child:StatCard(icon:'👨🏾‍🌾',label:'Registered Farmers',value:'${farmers.length}')),SizedBox(width:210,child:StatCard(icon:'⏳',label:'Pending Approvals',value:'$pending')),SizedBox(width:210,child:StatCard(icon:'✅',label:'Approved Farmers',value:'$approved',color:green)),SizedBox(width:210,child:StatCard(icon:'❌',label:'Rejected Farmers',value:'$rejected',color:red)),SizedBox(width:210,child:StatCard(icon:'🛡️',label:'Administrators',value:'$admins'))]),const SizedBox(height:16),Text('Registration Requests',style:Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight:FontWeight.bold)),const SizedBox(height:8),...(farmers.where((u)=>'${u['status']}'=='pending').isEmpty?[const EmptyCard(text:'No pending farmer registration requests.')]:farmers.where((u)=>'${u['status']}'=='pending').map((u)=>Card(child:ListTile(title:Text('${u['name']}'),subtitle:Text('${u['email']??'No email'} · ${u['phone']??'No phone'} · Registered ${u['created_at']}'),trailing:Wrap(children:[FilledButton.tonal(onPressed:()=>c.approveFarmer(int.parse('${u['id']}')),child:const Text('Approve')),const SizedBox(width:4),TextButton(onPressed:()=>c.rejectFarmer(int.parse('${u['id']}')),child:const Text('Reject',style:TextStyle(color:red)))]))).toList()),const SizedBox(height:16),Text('Recent Farmer Accounts',style:Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight:FontWeight.bold)),const SizedBox(height:8),Column(children:[for(final u in farmers.take(10))Card(child:ListTile(leading:const CircleAvatar(child:Text('🌱')),title:Text('${u['name']}'),subtitle:Text('${u['email']??u['phone']??'No contact'} · Farmer · ${u['status']}'),trailing:Chip(label:Text('${u['status']}'))))])]);}}

class AdminUsersPage extends StatelessWidget { final AppController c; const AdminUsersPage(this.c,{super.key}); @override Widget build(BuildContext context){final users=c.adminUsers();return PageFrame(c:c,title:'👥 Farmer Management',subtitle:'Review farmer accounts and approve or reject pending registrations.',child:Column(children:[for(final u in users)Card(child:ListTile(leading:CircleAvatar(child:Text('${u['role']}'=='admin'?'🛡️':'🌱')),title:Text('${u['name']}'),subtitle:Text('${u['email']??'No email'} · ${u['phone']??'No phone'} · ${u['role']=='admin'?'Administrator':'Farmer'} · ${u['status']}'),trailing:u['role']=='user'&&u['status']=='pending'?Wrap(children:[FilledButton.tonal(onPressed:()=>c.approveFarmer(int.parse('${u['id']}')),child:const Text('Approve')),TextButton(onPressed:()=>c.rejectFarmer(int.parse('${u['id']}')),child:const Text('Reject',style:TextStyle(color:red))) ]):Chip(label:Text('${u['status']}'))))]));}}

class EmptyCard extends StatelessWidget { final String text; const EmptyCard({super.key,required this.text}); @override Widget build(BuildContext c)=>Card(child:Padding(padding:const EdgeInsets.all(24),child:Center(child:Text(text)))); }

Future<void> _deleteRow(BuildContext context,AppController c,String table,Map<String,dynamic> row)async{final ok=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(title:const Text('Delete this record?'),content:const Text('This action cannot be undone.'),actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('Delete'))]));if(ok==true){final id=int.tryParse('${row['id']}');if(id!=null){await c.store.deleteWhere(table,id);await c.queueChange(table,'delete',row);c.notifyListeners();}}}

Future<void> _openPlant(BuildContext context,AppController c,[Map<String,dynamic>? existing]) async {final name=TextEditingController(text:'${existing?['name']??''}');final date=TextEditingController(text:'${existing?['planting_date']??''}');final area=TextEditingController(text:'${existing?['area']??''}');String icon='${existing?['icon']??'🌱'}';await showDialog(context:context,builder:(_)=>AlertDialog(title:Text(existing==null?'Add Plant':'Edit Plant'),content:SizedBox(width:420,child:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:name,decoration:const InputDecoration(labelText:'Plant/crop name',border:OutlineInputBorder())),const SizedBox(height:10),TextField(controller:date,decoration:const InputDecoration(labelText:'Planting date',hintText:'YYYY-MM-DD',border:OutlineInputBorder())),const SizedBox(height:10),TextField(controller:area,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'Area (hectares)',border:OutlineInputBorder())),const SizedBox(height:10),StatefulBuilder(builder:(context,setLocal)=>DropdownButtonFormField<String>(value:icon,decoration:const InputDecoration(labelText:'Icon',border:OutlineInputBorder()),items:const ['🌽','🌿','🍅','🥬','🥔','🌱'].map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(),onChanged:(v)=>setLocal(()=>icon=v!)))])),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Cancel')),FilledButton(onPressed:()async{if(name.text.trim().isEmpty){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Plant name is required.')));return;}if(!validPlantingDate(date.text.trim())){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Planting date must use YYYY-MM-DD.')));return;}final id=existing==null?c.store.nextId('crops'):int.parse('${existing['id']}');final obj={'id':id,'user_id':c.currentUser?['id'],'name':name.text.trim(),'planting_date':date.text.trim().isEmpty?null:date.text.trim(),'area':(double.tryParse(area.text) ?? 0.0),'icon':icon,'created_at':existing?['created_at']??now()};if(existing==null)await c.store.add('crops',obj);else await c.store.updateWhere('crops',id,obj);await c.queueChange('crops',existing==null?'create':'update',obj);c.notifyListeners();if(context.mounted)Navigator.pop(context);},child:const Text('Save Plant'))]));}

Future<void> _openLivestock(BuildContext context,AppController c) async {final qty=TextEditingController(text:'1');String animal='Cattle',record='Added';await showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('Add Livestock'),content:Column(mainAxisSize:MainAxisSize.min,children:[DropdownButtonFormField<String>(value:animal,items:const ['Cattle','Goats','Chickens','Sheep','Pigs','Rabbits'].map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(),onChanged:(v)=>animal=v!),const SizedBox(height:10),TextField(controller:qty,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Quantity',border:OutlineInputBorder())),const SizedBox(height:10),DropdownButtonFormField<String>(value:record,items:const ['Added','Birth','Sale'].map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(),onChanged:(v)=>record=v!) ]),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Cancel')),FilledButton(onPressed:()async{final obj={'id':c.store.nextId('livestock'),'user_id':c.currentUser?['id'],'animal_type':animal,'quantity':int.tryParse(qty.text)??1,'record_type':record,'record_date':today()};await c.store.add('livestock',obj);await c.queueChange('livestock','create',obj);await c.addNotification(int.tryParse('${c.currentUser?['id']}')??0,'livestock','Livestock updated','${obj['quantity']} ${obj['animal_type']} recorded as ${obj['record_type']}.');c.notifyListeners();if(context.mounted)Navigator.pop(context);},child:const Text('Save Record'))]));}

Future<void> _openExpense(BuildContext context,AppController c) async {final desc=TextEditingController();final amount=TextEditingController();String cat='Fertilizer';await showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('Record Purchase'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:desc,decoration:const InputDecoration(labelText:'Description',hintText:'Fertilizer / feed / equipment',border:OutlineInputBorder())),const SizedBox(height:10),DropdownButtonFormField<String>(value:cat,items:const ['Fertilizer','Feed','Seeds','Equipment','Transport','Labour','Other'].map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(),onChanged:(v)=>cat=v!),const SizedBox(height:10),TextField(controller:amount,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'Amount (R)',border:OutlineInputBorder()))]),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Cancel')),FilledButton(onPressed:()async{final a=double.tryParse(amount.text);if(desc.text.trim().isEmpty||a==null||a<0){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Enter a valid description and amount.')));return;}final obj={'id':c.store.nextId('expenses'),'user_id':c.currentUser?['id'],'description':desc.text.trim(),'category':cat,'amount':a,'expense_date':today()};await c.store.add('expenses',obj);await c.queueChange('expenses','create',obj);await c.addNotification(int.tryParse('${c.currentUser?['id']}')??0,'purchase','Purchase recorded','${obj['description']} — ${money(a)}.');c.notifyListeners();if(context.mounted)Navigator.pop(context);},child:const Text('Save Purchase'))]));}

Future<void> _openIncome(BuildContext context,AppController c) async {final item=TextEditingController();final qty=TextEditingController();final amount=TextEditingController();await showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('Record Sale'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:item,decoration:const InputDecoration(labelText:'Item sold',hintText:'Maize / cattle / vegetables',border:OutlineInputBorder())),const SizedBox(height:10),TextField(controller:qty,decoration:const InputDecoration(labelText:'Quantity',hintText:'100 kg / 2 cattle',border:OutlineInputBorder())),const SizedBox(height:10),TextField(controller:amount,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'Amount (R)',border:OutlineInputBorder()))]),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Cancel')),FilledButton(onPressed:()async{final a=double.tryParse(amount.text);if(item.text.trim().isEmpty||a==null||a<0){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Enter a valid item and amount.')));return;}final obj={'id':c.store.nextId('income'),'user_id':c.currentUser?['id'],'item':item.text.trim(),'quantity':qty.text.trim(),'amount':a,'sale_date':today()};await c.store.add('income',obj);await c.queueChange('income','create',obj);await c.addNotification(int.tryParse('${c.currentUser?['id']}')??0,'sale','Sale recorded','${obj['item']} — ${money(a)}.');c.notifyListeners();if(context.mounted)Navigator.pop(context);},child:const Text('Save Sale'))]));}

Future<void> _openMarket(BuildContext context,AppController c,[Map<String,dynamic>? existing]) async {final product=TextEditingController(text:'${existing?['product']??''}');final price=TextEditingController(text:'${existing?['price']??''}');final notes=TextEditingController(text:'${existing?['notes']??''}');String category='${existing?['category']??'Crop'}';String unit='${existing?['unit']??'kg'}';await showDialog(context:context,builder:(_)=>AlertDialog(title:Text(existing==null?'Add Catalogue Price':'Edit Catalogue Price'),content:SizedBox(width:420,child:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:product,decoration:const InputDecoration(labelText:'Product',hintText:'Maize, tomatoes, eggs...',border:OutlineInputBorder())),const SizedBox(height:10),DropdownButtonFormField<String>(value:category,items:const ['Crop','Livestock','Other'].map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(),onChanged:(v)=>category=v!),const SizedBox(height:10),DropdownButtonFormField<String>(value:unit,items:const ['kg','ton','bag','crate','head','dozen','each'].map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(),onChanged:(v)=>unit=v!),const SizedBox(height:10),TextField(controller:price,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'Your price (R)',border:OutlineInputBorder())),const SizedBox(height:10),TextField(controller:notes,decoration:const InputDecoration(labelText:'Notes (optional)',hintText:'Quality, grade, size, etc.',border:OutlineInputBorder()))])),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Cancel')),FilledButton(onPressed:()async{final p=double.tryParse(price.text);if(product.text.trim().isEmpty||p==null||p<0){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Enter a valid product and price.')));return;}final id=existing==null?c.store.nextId('market_catalogue'):int.parse('${existing['id']}');final obj={'id':id,'user_id':c.currentUser?['id'],'product':product.text.trim(),'category':category,'unit':unit,'price':p,'notes':notes.text.trim(),'created_at':existing?['created_at']??now(),'updated_at':now()};if(existing==null)await c.store.add('market_catalogue',obj);else await c.store.updateWhere('market_catalogue',id,obj);await c.queueChange('market_catalogue',existing==null?'create':'update',obj);c.notifyListeners();if(context.mounted)Navigator.pop(context);},child:const Text('Save Price'))]));}

Future<void> _profile(BuildContext context,AppController c)async{final me=c.currentUser!;final n=TextEditingController(text:'${me['name']}');final e=TextEditingController(text:'${me['email']??''}');final p=TextEditingController(text:'${me['phone']??''}');await showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('Profile'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:n,decoration:const InputDecoration(labelText:'Full name',border:OutlineInputBorder())),const SizedBox(height:10),TextField(controller:e,keyboardType:TextInputType.emailAddress,decoration:const InputDecoration(labelText:'Email',border:OutlineInputBorder())),const SizedBox(height:10),TextField(controller:p,keyboardType:TextInputType.phone,inputFormatters:[FilteringTextInputFormatter.digitsOnly],maxLength:10,decoration:const InputDecoration(labelText:'Phone number',hintText:'10 digits only',border:OutlineInputBorder(),counterText:''))]),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Cancel')),FilledButton(onPressed:()async{if(p.text.isNotEmpty&&!validPhone(p.text)){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Phone number must contain exactly 10 digits.')));return;}if(n.text.trim().isEmpty||(e.text.trim().isEmpty&&p.text.trim().isEmpty)){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Name and at least one contact method are required.')));return;}await c.updateProfile(name:n.text,email:e.text,phone:p.text);if(context.mounted)Navigator.pop(context);},child:const Text('Save Profile'))]));}
